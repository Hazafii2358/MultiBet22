import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { ArrowLeft, RotateCcw, ExternalLink, Share2, Chrome as Home, Shield } from 'lucide-react-native';
import { WebView } from 'react-native-webview';
import type { WebView as WebViewType } from 'react-native-webview';

export default function WebViewScreen() {
  const { url, name } = useLocalSearchParams<{ url: string; name: string }>();
  const webViewRef = useRef<WebViewType>(null);
  const [loading, setLoading] = useState(false);
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);
  const [currentUrl, setCurrentUrl] = useState<string>('');

  const decodedUrl = decodeURIComponent(url || '');
  const platformName = decodeURIComponent(name || 'Plateforme');

  const handleBack = () => {
    if (canGoBack && webViewRef.current) {
      webViewRef.current.goBack();
    } else {
      router.back();
    }
  };

  const handleReload = () => {
    if (webViewRef.current) {
      webViewRef.current.reload();
    }
  };

  const handleOpenExternal = () => {
    Alert.alert(
      'Ouvrir dans le navigateur',
      'Voulez-vous ouvrir cette page dans votre navigateur externe ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { 
          text: 'Ouvrir', 
          onPress: () => {
            if (typeof window !== 'undefined') {
              window.open(currentUrl || decodedUrl, '_blank', 'noopener,noreferrer');
            }
          }
        }
      ]
    );
  };

  const handleShare = () => {
    Alert.alert(
      'Partager',
      `Partager ${platformName}`,
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Copier le lien', onPress: () => {
          // Copier dans le presse-papier (simulation)
          Alert.alert('Lien copié', 'Le lien a été copié dans le presse-papier');
        }}
      ]
    );
  };

  const handleNavigationStateChange = (navState: any) => {
    setCanGoBack(navState.canGoBack);
    setCanGoForward(navState.canGoForward);
    setCurrentUrl(navState.url);
  };

  const handleLoadStart = () => {
    setLoading(true);
  };

  const handleLoadEnd = () => {
    setLoading(false);
  };

  const handleError = () => {
    setLoading(false);
    Alert.alert(
      'Erreur de chargement',
      'Impossible de charger cette page. Vérifiez votre connexion internet.',
      [
        { text: 'Réessayer', onPress: handleReload },
        { text: 'Retour', onPress: () => router.back() }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity style={styles.headerButton} onPress={handleBack}>
            <ArrowLeft size={24} color="#111827" />
          </TouchableOpacity>
          <View style={styles.titleContainer}>
            <Text style={styles.title} numberOfLines={1}>
              {platformName}
            </Text>
            <Text style={styles.url} numberOfLines={1}>
              {currentUrl || decodedUrl}
            </Text>
          </View>
        </View>
        
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.headerButton} onPress={handleReload}>
            <RotateCcw size={20} color="#6b7280" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton} onPress={handleShare}>
            <Share2 size={20} color="#6b7280" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton} onPress={handleOpenExternal}>
            <ExternalLink size={20} color="#6b7280" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Loading Indicator */}
      {loading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="small" color="#22c55e" />
          <Text style={styles.loadingText}>Chargement de {platformName}...</Text>
        </View>
      )}

      {/* WebView */}
      <WebView
        ref={webViewRef}
        source={{ uri: decodedUrl }}
        style={styles.webview}
        onNavigationStateChange={handleNavigationStateChange}
        onLoadStart={handleLoadStart}
        onLoadEnd={handleLoadEnd}
        onError={handleError}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        scalesPageToFit={true}
        allowsBackForwardNavigationGestures={true}
        userAgent="Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1 MultiBetGuinee/1.0"
      />

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <TouchableOpacity 
          style={[styles.navButton, !canGoBack && styles.disabledButton]} 
          onPress={handleBack}
          disabled={!canGoBack}
        >
          <ArrowLeft size={20} color={canGoBack ? "#111827" : "#d1d5db"} />
          <Text style={[styles.navText, !canGoBack && styles.disabledText]}>
            Retour
          </Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => router.push('/(tabs)')}
        >
          <Home size={20} color="#22c55e" />
          <Text style={[styles.navText, { color: '#22c55e' }]}>
            Accueil
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navButton}>
          <Shield size={20} color="#6b7280" />
          <Text style={styles.navText}>Sécurisé</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  headerButton: {
    padding: 8,
    marginRight: 8,
  },
  titleContainer: {
    flex: 1,
    marginLeft: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  url: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 2,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: '#f9fafb',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  loadingText: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 8,
  },
  webview: {
    flex: 1,
  },
  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 12,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  navButton: {
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 12,
  },
  disabledButton: {
    opacity: 0.5,
  },
  navText: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
    fontWeight: '500',
  },
  disabledText: {
    color: '#d1d5db',
  },
});