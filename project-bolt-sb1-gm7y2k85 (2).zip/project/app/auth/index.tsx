import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { router, useRouter } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { User, Mail, Lock, Eye, EyeOff } from 'lucide-react-native';
import { Phone } from 'lucide-react-native';
import { RefreshCw } from 'lucide-react-native';
import MultiBetLogo from '@/components/MultiBetLogo';
import { AuthDiagnostic } from '@/lib/auth-diagnostic';
import AuthDebugPanel from '@/components/AuthDebugPanel';

export default function AuthScreen() {
  const router = useRouter();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showDebug, setShowDebug] = useState(false);

  const { signIn, signUp, user } = useAuth();

  // Redirection automatique si l'utilisateur est déjà connecté
  React.useEffect(() => {
    if (user) {
      console.log('🔄 AuthScreen: Utilisateur connecté → /(tabs)');
      router.replace('/(tabs)');
    }
  }, [user, router]);

  const handleSubmit = async () => {
    console.log('=== DÉBUT AUTHENTIFICATION ===');
    console.log('Mode:', isLogin ? 'Connexion' : 'Inscription');
    console.log('Email:', email);
    console.log('Nom complet:', fullName);
    
    if (!email || !password) {
      Alert.alert('Erreur', 'Veuillez remplir tous les champs obligatoires');
      return;
    }

    if (!isLogin) {
      if (!fullName) {
        Alert.alert('Erreur', 'Veuillez entrer votre nom complet');
        return;
      }
      if (!phoneNumber) {
        Alert.alert('Erreur', 'Veuillez entrer votre numéro de téléphone');
        return;
      }
      if (phoneNumber.length < 8) {
        Alert.alert('Erreur', 'Le numéro de téléphone doit contenir au moins 8 chiffres');
        return;
      }
      if (password !== confirmPassword) {
        Alert.alert('Erreur', 'Les mots de passe ne correspondent pas');
        return;
      }
      if (password.length < 6) {
        Alert.alert('Erreur', 'Le mot de passe doit contenir au moins 6 caractères');
        return;
      }
    }

    setLoading(true);

    try {
      let result;
      if (isLogin) {
        console.log('Tentative de connexion...');
        result = await signIn(email, password);
      } else {
        console.log('Tentative d\'inscription...');
        result = await signUp(email, password, fullName, phoneNumber);
      }

      console.log('Résultat authentification:', result);

      if (result.error) {
        console.error('Erreur authentification:', result.error);
        
        // Gestion spécifique de l'erreur de confirmation d'email
        if (result.error.includes('Email not confirmed')) {
          Alert.alert(
            'Email non confirmé',
            'Votre adresse email n\'a pas été confirmée. Veuillez vérifier votre boîte de réception pour le lien de confirmation.',
            [
              { text: 'OK', style: 'default' }
            ]
          );
        } else {
          Alert.alert(
            'Erreur',
            result.error || 'Une erreur est survenue'
          );
        }
      } else {
        console.log('Authentification réussie');
        // Redirection immédiate pour connexion ET inscription
        console.log('Redirection vers tabs...');
        router.replace('/(tabs)');
      }
    } catch (error) {
      console.error('Erreur handleSubmit:', error);
      Alert.alert('Erreur', 'Une erreur inattendue est survenue');
    } finally {
      setLoading(false);
      console.log('=== FIN AUTHENTIFICATION ===');
    }
  };

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setFullName('');
    setPhoneNumber('');
    setConfirmPassword('');
  };

  const toggleMode = () => {
    setIsLogin(!isLogin);
    resetForm();
  };

  return (
    <>
      <SafeAreaView style={styles.container}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.keyboardView}
        >
          <ScrollView contentContainerStyle={styles.scrollContent}>
            <View style={styles.header}>
              <MultiBetLogo width={200} height={50} />
              <Text style={styles.subtitle}>
                {isLogin ? 'Connectez-vous à votre compte' : 'Créez votre compte unique'}
              </Text>
              <Text style={styles.description}>
                Votre plateforme de comparaison des sites de paris
              </Text>
            </View>

            <View style={styles.form}>
              {!isLogin && (
                <View style={styles.inputContainer}>
                  <User size={20} color="#6b7280" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Nom complet"
                    value={fullName}
                    onChangeText={setFullName}
                    autoCapitalize="words"
                  />
                </View>
              )}

              {!isLogin && (
                <View style={styles.inputContainer}>
                  <Phone size={20} color="#6b7280" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Numéro de téléphone (+224...)"
                    value={phoneNumber}
                    onChangeText={setPhoneNumber}
                    keyboardType="phone-pad"
                    autoCapitalize="none"
                  />
                </View>
              )}

              <View style={styles.inputContainer}>
                <Mail size={20} color="#6b7280" style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Adresse email"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>

              <View style={styles.inputContainer}>
                <Lock size={20} color="#6b7280" style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Mot de passe"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                />
                <TouchableOpacity
                  style={styles.eyeIcon}
                  onPress={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff size={20} color="#6b7280" />
                  ) : (
                    <Eye size={20} color="#6b7280" />
                  )}
                </TouchableOpacity>
              </View>

              {!isLogin && (
                <View style={styles.inputContainer}>
                  <Lock size={20} color="#6b7280" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Confirmer le mot de passe"
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    secureTextEntry={!showPassword}
                    autoCapitalize="none"
                  />
                </View>
              )}

              <TouchableOpacity
                style={[styles.submitButton, loading && styles.disabledButton]}
                onPress={handleSubmit}
                disabled={loading}
              >
                <Text style={styles.submitButtonText}>
                  {loading
                    ? 'Chargement...'
                    : isLogin
                    ? 'Se connecter'
                    : 'Créer le compte'}
                </Text>
              </TouchableOpacity>

              <View style={styles.switchContainer}>
                <Text style={styles.switchText}>
                  {isLogin
                    ? "Vous n'avez pas de compte ?"
                    : 'Vous avez déjà un compte ?'}
                </Text>
                <TouchableOpacity onPress={toggleMode}>
                  <Text style={styles.switchLink}>
                    {isLogin ? 'Créer un compte' : 'Se connecter'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.benefits}>
              <Text style={styles.benefitsTitle}>Avantages de votre compte MultiBet :</Text>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitBullet}>✓</Text>
                <Text style={styles.benefitText}>
                  Accès unifié à toutes les plateformes
                </Text>
              </View>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitBullet}>✓</Text>
                <Text style={styles.benefitText}>
                  Suivi de vos statistiques globales
                </Text>
              </View>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitBullet}>✓</Text>
                <Text style={styles.benefitText}>
                  Comparaison personnalisée des offres
                </Text>
              </View>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitBullet}>✓</Text>
                <Text style={styles.benefitText}>
                  Outils de jeu responsable
                </Text>
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
        
        {/* Debug Panel */}
        <AuthDebugPanel visible={showDebug} onClose={() => setShowDebug(false)} />
        
        {/* Debug Button - En bas à droite */}
        <TouchableOpacity
          style={styles.debugButton}
          onPress={() => setShowDebug(true)}
        >
          <Text style={styles.debugButtonText}>🐛</Text>
        </TouchableOpacity>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginTop: 20,
    textAlign: 'center',
  },
  description: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 8,
    textAlign: 'center',
    lineHeight: 20,
  },
  form: {
    marginBottom: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 4,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
    paddingVertical: 12,
  },
  eyeIcon: {
    padding: 4,
  },
  submitButton: {
    backgroundColor: '#22c55e',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  disabledButton: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  switchText: {
    fontSize: 14,
    color: '#6b7280',
  },
  switchLink: {
    fontSize: 14,
    color: '#22c55e',
    fontWeight: '600',
    marginLeft: 4,
  },
  benefits: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  benefitsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 15,
    textAlign: 'center',
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  benefitBullet: {
    fontSize: 16,
    color: '#22c55e',
    fontWeight: 'bold',
    marginRight: 10,
    width: 20,
  },
  benefitText: {
    fontSize: 14,
    color: '#374151',
    flex: 1,
  },
  debugButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#f59e0b',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  debugButtonText: {
    fontSize: 20,
  },
  errorContainer: {
    backgroundColor: '#fef2f2',
    borderRadius: 8,
    padding: 12,
    marginTop: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#dc2626',
  },
  errorText: {
    color: '#dc2626',
    fontSize: 14,
    marginBottom: 8,
    textAlign: 'center',
  },
  reconnectButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#22c55e',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  reconnectText: {
    color: '#22c55e',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
});