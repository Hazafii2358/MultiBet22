import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Switch,
  Alert,
} from 'react-native';
import { User, Settings, Bell, Shield, CircleHelp as HelpCircle, CreditCard, ChartBar as BarChart3, LogOut, ChevronRight, Moon, Globe, Lock, Eye, EyeOff, TrendingUp, Trophy } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { router } from 'expo-router';

export default function ProfileScreen() {
  const { user, profile, signOut, loading } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [darkModeEnabled, setDarkModeEnabled] = useState(false);
  const [showStats, setShowStats] = useState(true);
  
  // Redirection si pas d'utilisateur
  React.useEffect(() => {
    if (!loading && !user) {
      console.log('🔄 ProfileScreen: Redirection vers /auth (pas d\'utilisateur)');
      router.replace('/auth');
    }
  }, [user, loading]);
  
  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Chargement...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const handleSignOut = async () => {
    try {
      console.log('🔴 Début déconnexion depuis ProfileScreen');
      
      // Déconnexion immédiate
      await signOut();
      
      // Redirection forcée
      console.log('🔄 Redirection vers /auth');
      router.replace('/auth');
      
    } catch (error) {
      console.error('Erreur handleSignOut:', error);
      // En cas d'erreur, forcer quand même la redirection
      router.replace('/auth');
    }
  };

  const profit = profile ? (profile.total_won || 0) - (profile.total_spent || 0) : 0;
  const memberSince = new Date(profile?.created_at || new Date()).toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'long',
  });

  const menuSections = [
    {
      title: 'Compte',
      items: [
        { icon: User, label: 'Informations personnelles', hasChevron: true },
        { icon: CreditCard, label: 'Moyens de paiement', hasChevron: true },
        { icon: BarChart3, label: 'Historique détaillé', hasChevron: true },
      ]
    },
    {
      title: 'Paramètres',
      items: [
        { 
          icon: Bell, 
          label: 'Notifications', 
          hasSwitch: true, 
          switchValue: notificationsEnabled,
          onSwitchChange: setNotificationsEnabled 
        },
        { 
          icon: Moon, 
          label: 'Mode sombre', 
          hasSwitch: true, 
          switchValue: darkModeEnabled,
          onSwitchChange: setDarkModeEnabled 
        },
        { icon: Globe, label: 'Langue', hasChevron: true, subtitle: 'Français' },
        { icon: Shield, label: 'Sécurité', hasChevron: true },
      ]
    },
    {
      title: 'Jeu responsable',
      items: [
        { icon: Lock, label: 'Limites de jeu', hasChevron: true },
        { icon: Eye, label: 'Auto-exclusion', hasChevron: true },
        { icon: HelpCircle, label: 'Centre d\'aide', hasChevron: true },
      ]
    }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.profileInfo}>
            <View style={styles.avatar}>
              <User size={40} color="#ffffff" />
            </View>
            <View style={styles.userDetails}>
              <Text style={styles.userName}>
                {profile?.full_name || user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Utilisateur'}
              </Text>
              <Text style={styles.userEmail}>{profile?.email || user?.email || ''}</Text>
              <Text style={styles.memberSince}>Membre depuis {memberSince}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.editButton}>
            <Settings size={20} color="#6b7280" />
          </TouchableOpacity>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statsHeader}>
            <Text style={styles.statsTitle}>Vos statistiques</Text>
            <TouchableOpacity onPress={() => setShowStats(!showStats)}>
              {showStats ? (
                <EyeOff size={20} color="#6b7280" />
              ) : (
                <Eye size={20} color="#6b7280" />
              )}
            </TouchableOpacity>
          </View>

          {showStats && (
            <View style={styles.statsGrid}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{profile?.total_bets || 0}</Text>
                <Text style={styles.statLabel}>Paris placés</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={[styles.statValue, { color: '#22c55e' }]}>
                  {profile?.win_rate || 0}%
                </Text>
                <Text style={styles.statLabel}>Taux de réussite</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={[styles.statValue, { color: '#22c55e' }]}>
                  {profit >= 0 ? '+' : ''}{profit.toLocaleString()} GNF
                </Text>
                <Text style={styles.statLabel}>Profit total</Text>
              </View>
            </View>
          )}

          <View style={styles.favoriteSection}>
            <Text style={styles.favoriteLabel}>Plateforme favorite :</Text>
            <Text style={styles.favoritePlatform}>
              {profile?.preferred_platforms && Array.isArray(profile.preferred_platforms) && profile.preferred_platforms.length > 0
                ? profile.preferred_platforms[0]
                : 'Aucune'}
            </Text>
          </View>
        </View>

        {/* Menu Sections */}
        {menuSections.map((section, sectionIndex) => (
          <View key={sectionIndex} style={styles.menuSection}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <View style={styles.menuItems}>
              {section.items.map((item, itemIndex) => (
                <TouchableOpacity key={itemIndex} style={styles.menuItem}>
                  <View style={styles.menuItemLeft}>
                    <View style={styles.iconContainer}>
                      <item.icon size={20} color="#6b7280" />
                    </View>
                    <View>
                      <Text style={styles.menuItemLabel}>{item.label}</Text>
                      {item.subtitle && (
                        <Text style={styles.menuItemSubtitle}>{item.subtitle}</Text>
                      )}
                    </View>
                  </View>
                  <View style={styles.menuItemRight}>
                    {item.hasSwitch && (
                      <Switch
                        value={item.switchValue}
                        onValueChange={item.onSwitchChange}
                        trackColor={{ false: '#f3f4f6', true: '#22c55e' }}
                        thumbColor={item.switchValue ? '#ffffff' : '#f3f4f6'}
                      />
                    )}
                    {item.hasChevron && (
                      <ChevronRight size={20} color="#9ca3af" />
                    )}
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* Danger Zone */}
        <View style={styles.dangerZone}>
          <Text style={styles.sectionTitle}>Zone de danger</Text>
          <TouchableOpacity style={styles.dangerItem} onPress={handleSignOut}>
            <LogOut size={20} color="#dc2626" />
            <Text style={styles.dangerText}>Se déconnecter</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfo}>
          <Text style={styles.appVersion}>MultiBet Guinée v1.0.0</Text>
          <Text style={styles.appDescription}>
            Votre hub de jeux responsable en Guinée
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#6b7280',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#22c55e',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 2,
  },
  memberSince: {
    fontSize: 12,
    color: '#9ca3af',
  },
  editButton: {
    padding: 8,
  },
  statsContainer: {
    backgroundColor: '#ffffff',
    margin: 20,
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  statsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#22c55e',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    textAlign: 'center',
  },
  favoriteSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#f3f4f6',
  },
  favoriteLabel: {
    fontSize: 14,
    color: '#6b7280',
  },
  favoritePlatform: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
  },
  menuSection: {
    marginHorizontal: 20,
    marginBottom: 25,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  menuItems: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f9fafb',
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f9fafb',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  menuItemLabel: {
    fontSize: 16,
    color: '#111827',
    fontWeight: '500',
  },
  menuItemSubtitle: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
  },
  menuItemRight: {
    alignItems: 'center',
  },
  dangerZone: {
    marginHorizontal: 20,
    marginBottom: 25,
  },
  dangerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  dangerText: {
    fontSize: 16,
    color: '#dc2626',
    fontWeight: '500',
    marginLeft: 12,
  },
  appInfo: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  appVersion: {
    fontSize: 14,
    color: '#9ca3af',
    marginBottom: 4,
  },
  appDescription: {
    fontSize: 12,
    color: '#d1d5db',
    textAlign: 'center',
  },
  profilesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 4,
    paddingVertical: 8,
  },
  toggleText: {
    fontSize: 14,
    color: '#22c55e',
    fontWeight: '600',
  },
  profilesList: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  profileItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f9fafb',
  },
  profileAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#dcfce7',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  profileDetails: {
    flex: 1,
  },
  profileName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  profileEmail: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 2,
  },
  profileStats: {
    fontSize: 12,
    color: '#22c55e',
    marginBottom: 2,
  },
  profileDate: {
    fontSize: 12,
    color: '#9ca3af',
  },
  profileBadge: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '600',
  },
  noProfilesText: {
    textAlign: 'center',
    color: '#6b7280',
    padding: 20,
    fontSize: 14,
  },
});