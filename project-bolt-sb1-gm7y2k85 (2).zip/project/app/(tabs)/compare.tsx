import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
} from 'react-native';
import { TrendingUp, Star, Clock, DollarSign, Filter } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { Platform } from '@/lib/database.types';
import { router } from 'expo-router';

export default function CompareScreen() {
  const [selectedCategory, setSelectedCategory] = useState('tous');
  const [sortBy, setSortBy] = useState('cotes');
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [loading, setLoading] = useState(true);

  const categories = [
    { id: 'tous', label: 'Tous' },
    { id: 'sport', label: 'Paris sportifs' },
    { id: 'loterie', label: 'Loterie' },
    { id: 'casino', label: 'Casino' },
  ];

  // Mapping des logos locaux
  const logoMapping: { [key: string]: any } = {
    '1xbet.png': require('@/assets/images/1xbet.png'),
    'yellowbet.png': require('@/assets/images/yellowbet.png'),
    'geniusbet.png': require('@/assets/images/geniusbet.png'),
    'guinee-millions.png': require('@/assets/images/guinee-millions.png'),
    'lonagui.jpg': require('@/assets/images/lonagui.jpg'),
    'guinee-games.png': require('@/assets/images/guinee-games.png'),
  };

  useEffect(() => {
    loadPlatforms();
  }, []);

  const loadPlatforms = async () => {
    try {
      if (!supabase) {
        console.warn('⚠️ Supabase non configuré - Utilisation de données de démonstration');
        setPlatforms([]);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('platforms')
        .select('*')
        .order('rating', { ascending: false });

      if (error) {
        console.error('Erreur chargement plateformes:', error);
      } else if (data) {
        setPlatforms(data);
      }
    } catch (error) {
      console.error('Erreur loadPlatforms:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fonction pour trouver les meilleures cotes par championnat
  const getBestOddsForChampionship = (championship: string) => {
    let bestOdds = 0;
    platforms.forEach(platform => {
      if (platform.championship_odds && platform.championship_odds[championship]) {
        const odds = platform.championship_odds[championship];
        if (odds > bestOdds) {
          bestOdds = odds;
        }
      }
    });
    return bestOdds;
  };

  // Fonction pour calculer le pourcentage par rapport aux meilleures cotes
  const getOddsPercentage = (platform: Platform, championship: string) => {
    if (!platform.championship_odds || !platform.championship_odds[championship]) {
      return 0;
    }
    const platformOdds = platform.championship_odds[championship];
    const bestOdds = getBestOddsForChampionship(championship);
    if (bestOdds === 0) return 0;
    return Math.round((platformOdds / bestOdds) * 100);
  };

  // Fonction pour vérifier si une plateforme a les meilleures cotes pour un championnat
  const hasBestOdds = (platform: Platform, championship: string) => {
    if (!platform.championship_odds || !platform.championship_odds[championship]) {
      return false;
    }
    const platformOdds = platform.championship_odds[championship];
    const bestOdds = getBestOddsForChampionship(championship);
    return platformOdds === bestOdds;
  };

  // Fonction pour ouvrir directement le championnat
  const openChampionshipDirect = (platform: Platform, championship: string) => {
    if (platform.championship_links && platform.championship_links[championship]) {
      const encodedUrl = encodeURIComponent(platform.championship_links[championship]);
      const encodedName = encodeURIComponent(`${platform.name} - ${championship}`);
      router.push(`/webview/${encodedUrl}?name=${encodedName}`);
    }
  };

  const filteredPlatforms = platforms.filter(platform => 
    selectedCategory === 'tous' || platform.category === selectedCategory
  );

  const sortedPlatforms = [...filteredPlatforms].sort((a, b) => {
    switch (sortBy) {
      case 'rating':
        return b.rating - a.rating;
      case 'jackpot':
        return parseFloat(b.jackpot.replace(/[^\d.]/g, '')) - parseFloat(a.jackpot.replace(/[^\d.]/g, ''));
      case 'processing':
        return parseInt(a.processing_time) - parseInt(b.processing_time);
      default:
        return 0;
    }
  });

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Chargement des plateformes...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Comparateur</Text>
          <Text style={styles.subtitle}>Trouvez la meilleure plateforme pour vous</Text>
        </View>

        {/* Filters */}
        <View style={styles.filtersContainer}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoriesScroll}>
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.categoryButton,
                  selectedCategory === category.id && styles.activeCategoryButton
                ]}
                onPress={() => setSelectedCategory(category.id)}
              >
                <Text style={[
                  styles.categoryText,
                  selectedCategory === category.id && styles.activeCategoryText
                ]}>
                  {category.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity style={styles.sortButton}>
            <Filter size={16} color="#6b7280" />
            <Text style={styles.sortText}>Trier par</Text>
          </TouchableOpacity>
        </View>

        {/* Sort Options */}
        <View style={styles.sortOptions}>
          {[
            { id: 'cotes', label: 'Meilleures cotes' },
            { id: 'rating', label: 'Note utilisateurs' },
            { id: 'jackpot', label: 'Jackpot le plus élevé' },
            { id: 'processing', label: 'Retrait rapide' },
          ].map((option) => (
            <TouchableOpacity
              key={option.id}
              style={[
                styles.sortOption,
                sortBy === option.id && styles.activeSortOption
              ]}
              onPress={() => setSortBy(option.id)}
            >
              <Text style={[
                styles.sortOptionText,
                sortBy === option.id && styles.activeSortOptionText
              ]}>
                {option.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Platforms List */}
        <View style={styles.platformsList}>
          {sortedPlatforms.map((platform, index) => (
            <View key={platform.id} style={styles.platformCard}>
              <View style={styles.platformHeader}>
                <View style={styles.platformInfo}>
                  <View style={[styles.logoContainer, { backgroundColor: `${platform.color}20` }]}>
                    <Image
                      source={logoMapping[platform.logo_path]}
                      style={styles.logoImage}
                      resizeMode="contain"
                    />
                  </View>
                  <View style={styles.nameRating}>
                    <Text style={styles.platformName}>{platform.name}</Text>
                    <View style={styles.ratingContainer}>
                      <Star size={14} color="#eab308" fill="#eab308" />
                      <Text style={styles.rating}>{platform.rating}</Text>
                    </View>
                  </View>
                </View>
                <View style={styles.mainMetric}>
                  <Text style={styles.metricLabel}>Jackpot</Text>
                  <Text style={[styles.metricValue, { color: platform.color }]}>
                    {platform.jackpot}
                  </Text>
                </View>
              </View>

              <View style={styles.bonusSection}>
                <View style={styles.bonusTag}>
                  <Text style={styles.bonusText}>{platform.bonus_welcome}</Text>
                </View>
              </View>

              <View style={styles.metricsGrid}>
                <View style={styles.metric}>
                  <TrendingUp size={16} color="#6b7280" />
                  <Text style={styles.metricLabel}>Cotes</Text>
                  <Text style={styles.metricValue}>{platform.best_odds}</Text>
                </View>
                <View style={styles.metric}>
                  <Clock size={16} color="#6b7280" />
                  <Text style={styles.metricLabel}>Retrait</Text>
                  <Text style={styles.metricValue}>{platform.processing_time}</Text>
                </View>
                <View style={styles.metric}>
                  <DollarSign size={16} color="#6b7280" />
                  <Text style={styles.metricLabel}>Bonus</Text>
                  <Text style={styles.metricValue}>Oui</Text>
                </View>
              </View>

              <View style={styles.featuresSection}>
                <Text style={styles.featuresTitle}>Points forts :</Text>
                {platform.features.map((feature, idx) => (
                  <Text key={idx} style={styles.feature}>• {feature}</Text>
                ))}
                
                {platform.championships && platform.championships.length > 0 && (
                  <View style={styles.championshipsSection}>
                    <Text style={styles.championshipsTitle}>
                      {platform.category === 'sport' ? 'Championnats disponibles :' : 
                       platform.category === 'loterie' ? 'Types de jeux :' : 
                       'Tournois & Événements :'}
                    </Text>
                    <View style={styles.championshipsList}>
                      {platform.championships.map((championship, idx) => (
                        <TouchableOpacity 
                          key={idx} 
                          style={[
                          styles.championshipTag, 
                          { 
                            borderColor: hasBestOdds(platform, championship) ? '#eab308' : platform.color,
                            backgroundColor: hasBestOdds(platform, championship) ? '#fef3c7' : '#ffffff'
                          }
                        ]}
                          onPress={() => {
                            if (hasBestOdds(platform, championship)) {
                              openChampionshipDirect(platform, championship);
                            }
                          }}
                        >
                          <Text style={[
                            styles.championshipText, 
                            { 
                              color: hasBestOdds(platform, championship) ? '#92400e' : platform.color,
                              fontWeight: hasBestOdds(platform, championship) ? 'bold' : '600'
                            }
                          ]}>
                            {championship}
                            {hasBestOdds(platform, championship) && ' ⭐'}
                          </Text>
                          {getOddsPercentage(platform, championship) > 0 && (
                            <Text style={[
                              styles.oddsText,
                              { 
                                color: hasBestOdds(platform, championship) ? '#92400e' : '#6b7280'
                              }
                            ]}>
                              {getOddsPercentage(platform, championship)}% des meilleures cotes
                            </Text>
                          )}
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                )}
                
                <View style={styles.specialtySection}>
                  <Text style={styles.specialtyLabel}>Spécialité :</Text>
                  <Text style={styles.specialtyText}>{platform.specialties}</Text>
                </View>
              </View>

              <TouchableOpacity 
                style={[styles.visitButton, { backgroundColor: platform.color }]}
                onPress={() => {
                  const encodedUrl = encodeURIComponent(platform.website);
                  const encodedName = encodeURIComponent(platform.name);
                  router.push(`/webview/${encodedUrl}?name=${encodedName}`);
                }}
              >
                <Text style={styles.visitButtonText}>Visiter la plateforme</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#6b7280',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    marginTop: 4,
  },
  filtersContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  categoriesScroll: {
    flex: 1,
    marginRight: 15,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  activeCategoryButton: {
    backgroundColor: '#22c55e',
    borderColor: '#22c55e',
  },
  categoryText: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  activeCategoryText: {
    color: '#ffffff',
  },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  sortText: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 4,
  },
  sortOptions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    flexWrap: 'wrap',
  },
  sortOption: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginRight: 8,
    marginBottom: 8,
    borderRadius: 16,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  activeSortOption: {
    backgroundColor: '#22c55e',
    borderColor: '#22c55e',
  },
  sortOptionText: {
    fontSize: 12,
    color: '#6b7280',
  },
  activeSortOptionText: {
    color: '#ffffff',
  },
  platformsList: {
    paddingHorizontal: 20,
  },
  platformCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  platformHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  platformInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  logoContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  logoImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  nameRating: {
    flex: 1,
  },
  platformName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 4,
  },
  mainMetric: {
    alignItems: 'flex-end',
  },
  bonusSection: {
    marginBottom: 16,
  },
  bonusTag: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  bonusText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '600',
  },
  metricsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  metric: {
    alignItems: 'center',
    flex: 1,
  },
  metricLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  metricValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginTop: 2,
  },
  featuresSection: {
    marginBottom: 20,
  },
  featuresTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  feature: {
    fontSize: 13,
    color: '#6b7280',
    marginBottom: 3,
  },
  championshipsSection: {
    marginTop: 15,
  },
  championshipsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 10,
  },
  championshipsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 10,
  },
  championshipTag: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 6,
    marginBottom: 6,
    backgroundColor: '#ffffff',
  },
  championshipText: {
    fontSize: 11,
    fontWeight: '600',
  },
  oddsText: {
    fontSize: 10,
    marginTop: 2,
  },
  specialtySection: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#f3f4f6',
  },
  specialtyLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 4,
  },
  specialtyText: {
    fontSize: 13,
    color: '#374151',
    fontWeight: '500',
    fontStyle: 'italic',
  },
  visitButton: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  visitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});