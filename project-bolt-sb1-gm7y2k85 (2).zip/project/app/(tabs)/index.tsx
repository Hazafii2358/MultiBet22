import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
  Dimensions,
} from 'react-native';
import {
  TrendingUp,
  Star,
  Gift,
  Users,
  Clock,
  DollarSign,
  Trophy,
  Target,
  Zap,
  ChevronRight,
  ExternalLink,
  Bell,
  Wallet,
} from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Platform } from '@/lib/database.types';
import { router, useRouter } from 'expo-router';
import MultiBetLogo from '@/components/MultiBetLogo';

const { width } = Dimensions.get('window');

// Fonction pour obtenir la salutation selon l'heure
const getGreeting = () => {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) {
    return 'Bonjour';
  } else if (hour >= 12 && hour < 18) {
    return 'Bon après-midi';
  } else {
    return 'Bonsoir';
  }
};

export default function HomeScreen() {
  const { user, profile } = useAuth();
  const routerInstance = useRouter();
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [loading, setLoading] = useState(true);
  const [notifications] = useState([
    {
      id: 1,
      title: 'Nouvelle promotion',
      message: 'YellowBet offre 50% de bonus sur votre premier dépôt',
      time: '2h',
      type: 'promo',
      read: false,
    },
    {
      id: 2,
      title: 'Rappel de limite',
      message: 'Vous avez atteint 80% de votre limite hebdomadaire',
      time: '5h',
      type: 'warning',
      read: false,
    },
    {
      id: 3,
      title: 'Nouveau jackpot',
      message: 'Guinée Games: Jackpot de 500M GNF disponible',
      time: '1j',
      type: 'jackpot',
      read: true,
    },
  ]);

  // Mapping des logos locaux
  const logoMapping: { [key: string]: any } = {
    '1xbet.png': require('@/assets/images/1xbet.png'),
    'yellowbet.png': require('@/assets/images/yellowbet.png'),
    'geniusbet.png': require('@/assets/images/geniusbet.png'),
    'guinee-millions.png': require('@/assets/images/guinee-millions.png'),
    'lonagui.jpg': require('@/assets/images/lonagui.jpg'),
    'guinee-games.png': require('@/assets/images/guinee-games.png'),
  };

  // Redirection si pas d'utilisateur
  useEffect(() => {
    if (!user && routerInstance.isReady) {
      console.log('🔄 HomeScreen: Pas d\'utilisateur → /auth');
      routerInstance.replace('/auth');
    }
  }, [user, routerInstance.isReady]);

  useEffect(() => {
    loadPlatforms();
  }, []);

  const loadPlatforms = async () => {
    try {
      if (!supabase) {
        console.warn('⚠️ Supabase non configuré - Utilisation de données de démonstration');
        // Utiliser des données de démonstration si Supabase n'est pas configuré
        setPlatforms([]);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('platforms')
        .select('*')
        .order('rating', { ascending: false })
        .limit(6);

      if (error) {
        console.error('Erreur chargement plateformes:', error);
      } else if (data) {
        setPlatforms(data);
      }
    } catch (error) {
      console.error('Erreur loadPlatforms:', error);
    } finally {
      setLoading(false);
    }
  };

  const openPlatform = (platform: Platform) => {
    const encodedUrl = encodeURIComponent(platform.website);
    const encodedName = encodeURIComponent(platform.name);
    router.push(`/webview/${encodedUrl}?name=${encodedName}`);
  };

  if (!user) {
    return null; // Éviter le flash pendant la redirection
  }

  const balance = profile ? (profile.total_won || 0) - (profile.total_spent || 0) : 0;
  const unreadNotifications = notifications.filter(n => !n.read).length;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <MultiBetLogo width={140} height={30} />
            <View style={styles.headerActions}>
              <TouchableOpacity style={styles.balanceContainer}>
                <Wallet size={18} color="#22c55e" />
                <Text style={styles.balanceText}>
                  {balance >= 0 ? '+' : ''}{balance.toLocaleString()} GNF
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.notificationButton}>
                <Bell size={20} color="#6b7280" />
                {unreadNotifications > 0 && (
                  <View style={styles.notificationBadge}>
                    <Text style={styles.badgeText}>{unreadNotifications}</Text>
                  </View>
                )}
              </TouchableOpacity>
            </View>
          </View>
          <Text style={styles.welcomeText}>
            {getGreeting()} {profile?.full_name?.split(' ')[0] || user?.user_metadata?.full_name?.split(' ')[0] || 'Utilisateur'} 👋
          </Text>
          <Text style={styles.subtitle}>
            Découvrez les meilleures plateformes de jeux en Guinée
          </Text>
        </View>

        {/* Quick Stats */}
        {profile && (
          <View style={styles.quickStats}>
            <View style={styles.statCard}>
              <Trophy size={24} color="#eab308" />
              <Text style={styles.statValue}>{profile.total_bets || 0}</Text>
              <Text style={styles.statLabel}>Paris placés</Text>
            </View>
            <View style={styles.statCard}>
              <Target size={24} color="#22c55e" />
              <Text style={styles.statValue}>{profile.win_rate || 0}%</Text>
              <Text style={styles.statLabel}>Taux de réussite</Text>
            </View>
            <View style={styles.statCard}>
              <DollarSign size={24} color="#dc2626" />
              <Text style={styles.statValue}>
                {((profile.total_won || 0) - (profile.total_spent || 0)).toLocaleString()}
              </Text>
              <Text style={styles.statLabel}>Profit (GNF)</Text>
            </View>
          </View>
        )}

        {/* Notifications Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Notifications</Text>
            <TouchableOpacity style={styles.seeAllButton}>
              <Text style={styles.seeAllText}>Tout voir</Text>
              <ChevronRight size={16} color="#22c55e" />
            </TouchableOpacity>
          </View>
          
          <View style={styles.notificationsContainer}>
            {notifications.slice(0, 3).map((notification) => (
              <TouchableOpacity key={notification.id} style={styles.notificationCard}>
                <View style={styles.notificationLeft}>
                  <View style={[
                    styles.notificationIcon,
                    {
                      backgroundColor: 
                        notification.type === 'promo' ? '#dbeafe' :
                        notification.type === 'warning' ? '#fef3c7' :
                        '#dcfce7'
                    }
                  ]}>
                    {notification.type === 'promo' && <Gift size={16} color="#2563eb" />}
                    {notification.type === 'warning' && <Target size={16} color="#d97706" />}
                    {notification.type === 'jackpot' && <Trophy size={16} color="#16a34a" />}
                  </View>
                  <View style={styles.notificationContent}>
                    <Text style={[
                      styles.notificationTitle,
                      !notification.read && styles.unreadTitle
                    ]}>
                      {notification.title}
                    </Text>
                    <Text style={styles.notificationMessage}>
                      {notification.message}
                    </Text>
                  </View>
                </View>
                <View style={styles.notificationRight}>
                  <Text style={styles.notificationTime}>{notification.time}</Text>
                  {!notification.read && <View style={styles.unreadDot} />}
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Featured Platforms */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Plateformes populaires</Text>
            <TouchableOpacity 
              style={styles.seeAllButton}
              onPress={() => router.push('/(tabs)/platforms')}
            >
              <Text style={styles.seeAllText}>Voir tout</Text>
              <ChevronRight size={16} color="#22c55e" />
            </TouchableOpacity>
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.platformsScroll}>
            {platforms.map((platform) => (
              <TouchableOpacity
                key={platform.id}
                style={styles.platformCard}
                onPress={() => openPlatform(platform)}
              >
                <View style={[styles.platformLogo, { backgroundColor: `${platform.color}20` }]}>
                  <Image
                    source={logoMapping[platform.logo_path]}
                    style={styles.logoImage}
                    resizeMode="contain"
                  />
                </View>
                <Text style={styles.platformName}>{platform.name}</Text>
                <View style={styles.platformRating}>
                  <Star size={12} color="#eab308" fill="#eab308" />
                  <Text style={styles.ratingText}>{platform.rating}</Text>
                </View>
                <Text style={styles.platformCategory}>{platform.category}</Text>
                <View style={styles.platformBonus}>
                  <Gift size={12} color="#22c55e" />
                  <Text style={styles.bonusText}>Bonus</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Actions rapides</Text>
          <View style={styles.actionsGrid}>
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => router.push('/(tabs)/compare')}
            >
              <View style={[styles.actionIcon, { backgroundColor: '#dbeafe' }]}>
                <TrendingUp size={24} color="#2563eb" />
              </View>
              <Text style={styles.actionTitle}>Comparer</Text>
              <Text style={styles.actionSubtitle}>Trouvez les meilleures cotes</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => router.push('/(tabs)/education')}
            >
              <View style={[styles.actionIcon, { backgroundColor: '#fef3c7' }]}>
                <Zap size={24} color="#d97706" />
              </View>
              <Text style={styles.actionTitle}>Apprendre</Text>
              <Text style={styles.actionSubtitle}>Jeu responsable</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Latest Promotions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Promotions du moment</Text>
          <View style={styles.promotionsContainer}>
            {platforms.slice(0, 3).map((platform) => (
              <View key={platform.id} style={styles.promoCard}>
                <View style={styles.promoHeader}>
                  <Image
                    source={logoMapping[platform.logo_path]}
                    style={styles.promoLogo}
                    resizeMode="contain"
                  />
                  <Text style={styles.promoTitle}>{platform.name}</Text>
                </View>
                <Text style={styles.promoText}>{platform.bonus_welcome}</Text>
                <TouchableOpacity 
                  style={[styles.promoButton, { backgroundColor: platform.color }]}
                  onPress={() => openPlatform(platform)}
                >
                  <ExternalLink size={16} color="#ffffff" />
                  <Text style={styles.promoButtonText}>Profiter</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </View>

        {/* Tips Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Conseils du jour</Text>
          <View style={styles.tipsContainer}>
            <View style={styles.tipCard}>
              <Text style={styles.tipTitle}>💡 Conseil de sécurité</Text>
              <Text style={styles.tipText}>
                Ne jamais jouer avec de l'argent dont vous avez besoin pour vos dépenses essentielles.
              </Text>
            </View>
            <View style={styles.tipCard}>
              <Text style={styles.tipTitle}>📊 Astuce du jour</Text>
              <Text style={styles.tipText}>
                Comparez toujours les cotes entre plusieurs plateformes avant de placer votre pari.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  balanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  balanceText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#22c55e',
    marginLeft: 6,
  },
  notificationButton: {
    position: 'relative',
    backgroundColor: '#ffffff',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  notificationBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    backgroundColor: '#dc2626',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    lineHeight: 22,
  },
  quickStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginVertical: 20,
  },
  statCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
    borderWidth: 2,
    borderColor: '#22c55e',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#22c55e',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#374151',
    marginTop: 4,
    textAlign: 'center',
    fontWeight: '500',
  },
  section: {
    marginBottom: 30,
  },
  notificationsContainer: {
    paddingHorizontal: 20,
  },
  notificationCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  notificationLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  notificationIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#111827',
    marginBottom: 4,
  },
  unreadTitle: {
    fontWeight: '600',
  },
  notificationMessage: {
    fontSize: 13,
    color: '#6b7280',
    lineHeight: 18,
  },
  notificationRight: {
    alignItems: 'flex-end',
  },
  notificationTime: {
    fontSize: 12,
    color: '#9ca3af',
    marginBottom: 4,
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#22c55e',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
  },
  seeAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seeAllText: {
    fontSize: 14,
    color: '#22c55e',
    fontWeight: '600',
    marginRight: 4,
  },
  platformsScroll: {
    paddingLeft: 20,
  },
  platformCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginRight: 12,
    width: 140,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  platformLogo: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  logoImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  platformName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
    textAlign: 'center',
  },
  platformRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  ratingText: {
    fontSize: 12,
    color: '#6b7280',
    marginLeft: 4,
  },
  platformCategory: {
    fontSize: 11,
    color: '#9ca3af',
    marginBottom: 8,
    textAlign: 'center',
  },
  platformBonus: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0fdf4',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  bonusText: {
    fontSize: 10,
    color: '#15803d',
    marginLeft: 4,
    fontWeight: '600',
  },
  actionsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  actionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    flex: 0.48,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  actionIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  actionSubtitle: {
    fontSize: 12,
    color: '#6b7280',
    textAlign: 'center',
  },
  promotionsContainer: {
    paddingHorizontal: 20,
  },
  promoCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  promoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  promoLogo: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginRight: 10,
  },
  promoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  promoText: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 12,
    lineHeight: 20,
  },
  promoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
  },
  promoButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 6,
  },
  tipsContainer: {
    paddingHorizontal: 20,
  },
  tipCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#22c55e',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tipTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 6,
  },
  tipText: {
    fontSize: 13,
    color: '#6b7280',
    lineHeight: 18,
  },
});