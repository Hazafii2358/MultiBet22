import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
  Modal,
} from 'react-native';
import {
  ExternalLink,
  Star,
  Gift,
  Users,
  Clock,
  Shield,
  Smartphone,
  CreditCard,
  X,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { Platform } from '@/lib/database.types';
import { router } from 'expo-router';

export default function PlatformsScreen() {
  const [selectedPlatform, setSelectedPlatform] = useState(null);
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [loading, setLoading] = useState(true);

  // Mapping des logos locaux
  const logoMapping: { [key: string]: any } = {
    '1xbet.png': require('@/assets/images/1xbet.png'),
    'yellowbet.png': require('@/assets/images/yellowbet.png'),
    'geniusbet.png': require('@/assets/images/geniusbet.png'),
    'guinee-millions.png': require('@/assets/images/guinee-millions.png'),
    'lonagui.jpg': require('@/assets/images/lonagui.jpg'),
    'guinee-games.png': require('@/assets/images/guinee-games.png'),
  };

  useEffect(() => {
    loadPlatforms();
  }, []);

  const loadPlatforms = async () => {
    try {
      if (!supabase) {
        console.warn('⚠️ Supabase non configuré - Utilisation de données de démonstration');
        setPlatforms([]);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('platforms')
        .select('*')
        .order('rating', { ascending: false });

      if (error) {
        console.error('Erreur chargement plateformes:', error);
      } else if (data) {
        setPlatforms(data);
      }
    } catch (error) {
      console.error('Erreur loadPlatforms:', error);
    } finally {
      setLoading(false);
    }
  };

  const openInWebView = (url: string, platformName: string) => {
    const encodedUrl = encodeURIComponent(url);
    const encodedName = encodeURIComponent(platformName);
    router.push(`/webview/${encodedUrl}?name=${encodedName}`);
  };

  const openInExternalBrowser = (url: string) => {
    if (typeof window !== 'undefined') {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Chargement des plateformes...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Plateformes</Text>
          <Text style={styles.subtitle}>
            Découvrez toutes les plateformes disponibles
          </Text>
        </View>

        {/* Stats Overview */}
        <View style={styles.statsContainer}>
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>{platforms.length}</Text>
            <Text style={styles.statLabel}>Plateformes</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>
              {platforms.reduce((total, p) => total + parseInt(p.users_count.replace(/[^\d]/g, '') || '0'), 0) / 1000}k+
            </Text>
            <Text style={styles.statLabel}>Utilisateurs</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>100%</Text>
            <Text style={styles.statLabel}>Vérifiées</Text>
          </View>
        </View>

        {/* Platforms List */}
        <View style={styles.platformsList}>
          {platforms.map((platform) => (
            <TouchableOpacity
              key={platform.id}
              style={styles.platformCard}
              onPress={() =>
                setSelectedPlatform(
                  selectedPlatform === platform.id ? null : platform.id
                )
              }
            >
              <View style={styles.platformHeader}>
                <View style={styles.platformBasicInfo}>
                  <View
                    style={[
                      styles.logoContainer,
                      { backgroundColor: `${platform.color}20` },
                    ]}
                  >
                    <Image
                      source={logoMapping[platform.logo_path]}
                      style={styles.logoImage}
                      resizeMode="contain"
                    />
                  </View>
                  <View style={styles.nameAndCategory}>
                    <Text style={styles.platformName}>{platform.name}</Text>
                    <Text style={styles.category}>{platform.category}</Text>
                    <View style={styles.ratingRow}>
                      <Star size={14} color="#eab308" fill="#eab308" />
                      <Text style={styles.rating}>{platform.rating}</Text>
                      <Users size={14} color="#6b7280" />
                      <Text style={styles.users}>{platform.users_count}</Text>
                    </View>
                  </View>
                </View>
                <TouchableOpacity
                  style={[
                    styles.visitButton,
                    { backgroundColor: platform.color },
                  ]}
                  onPress={() => openInWebView(platform.website, platform.name)}
                >
                  <ExternalLink size={16} color="#ffffff" />
                </TouchableOpacity>
              </View>

              <View style={styles.descriptionContainer}>
                <Text style={styles.description}>{platform.description}</Text>
              </View>

              {/* Visit Website Button */}
              <TouchableOpacity
                style={[styles.visitWebsiteButton, { borderColor: platform.color }]}
                onPress={() => openInWebView(platform.website, platform.name)}
              >
                <ExternalLink size={18} color={platform.color} />
                <Text style={[styles.visitWebsiteText, { color: platform.color }]}>
                  Ouvrir {platform.name}
                </Text>
              </TouchableOpacity>

              {selectedPlatform === platform.id && (
                <View style={styles.expandedContent}>
                  {/* Platform Info */}
                  <View style={styles.infoGrid}>
                    <View style={styles.infoItem}>
                      <Clock size={16} color="#6b7280" />
                      <Text style={styles.infoLabel}>Fondée en</Text>
                      <Text style={styles.infoValue}>{platform.founded}</Text>
                    </View>
                    <View style={styles.infoItem}>
                      <Shield size={16} color="#6b7280" />
                      <Text style={styles.infoLabel}>Licence</Text>
                      <Text style={styles.infoValue}>{platform.license}</Text>
                    </View>
                  </View>

                  {/* Features */}
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Fonctionnalités</Text>
                    <View style={styles.featuresList}>
                      {platform.features.map((feature, index) => (
                        <View key={index} style={styles.featureItem}>
                          <View style={styles.featureDot} />
                          <Text style={styles.featureText}>{feature}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  {/* Current Promotions */}
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>
                      <Gift size={16} color="#22c55e" /> Promotions actuelles
                    </Text>
                    {platform.current_promotions.map((promo, index) => (
                      <View key={index} style={styles.promoItem}>
                        <Text style={styles.promoText}>{promo}</Text>
                      </View>
                    ))}
                  </View>

                  {/* Payment Methods */}
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>
                      <CreditCard size={16} color="#6b7280" /> Moyens de
                      paiement
                    </Text>
                    <View style={styles.paymentMethods}>
                      {platform.payment_methods.map((method, index) => (
                        <View key={index} style={styles.paymentMethod}>
                          <Text style={styles.paymentText}>{method}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  {/* Action Buttons */}
                  <View style={styles.actionButtons}>
                    <TouchableOpacity
                      style={[
                        styles.actionButton,
                        { backgroundColor: platform.color },
                      ]}
                    >
                      <Smartphone size={16} color="#ffffff" />
                      <Text style={styles.actionButtonText}>
                        Télécharger l'app
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.actionButton, styles.secondaryButton]}
                      onPress={() => {
                        const encodedUrl = encodeURIComponent(platform.website);
                        const encodedName = encodeURIComponent(platform.name);
                        router.push(`/webview/${encodedUrl}?name=${encodedName}`);
                      }}
                    >
                      <ExternalLink size={16} color={platform.color} />
                      <Text
                        style={[
                          styles.actionButtonText,
                          { color: platform.color },
                        ]}
                      >
                        Site web
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#6b7280',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  statBox: {
    alignItems: 'center',
    backgroundColor: '#ffffff',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 12,
    flex: 1,
    marginHorizontal: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#22c55e',
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  platformsList: {
    paddingHorizontal: 20,
  },
  platformCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  platformHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  platformBasicInfo: {
    flexDirection: 'row',
    flex: 1,
  },
  logoContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  logoImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  nameAndCategory: {
    flex: 1,
  },
  platformName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 2,
  },
  category: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 6,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 4,
    marginRight: 12,
  },
  users: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 4,
  },
  visitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  description: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
    marginBottom: 10,
  },
  descriptionContainer: {
    marginBottom: 15,
  },
  visitWebsiteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    borderWidth: 1,
    marginBottom: 10,
  },
  visitWebsiteText: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 6,
  },
  expandedContent: {
    borderTopWidth: 1,
    borderTopColor: '#f3f4f6',
    paddingTop: 20,
  },
  infoGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  infoItem: {
    alignItems: 'center',
    flex: 1,
  },
  infoLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginTop: 2,
    textAlign: 'center',
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  featuresList: {
    marginLeft: 10,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#dc2626',
    marginRight: 10,
  },
  featureText: {
    fontSize: 14,
    color: '#374151',
  },
  promoItem: {
    backgroundColor: '#f0fdf4',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#22c55e',
  },
  promoText: {
    fontSize: 14,
    color: '#15803d',
    fontWeight: '500',
  },
  paymentMethods: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  paymentMethod: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  paymentText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '500',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    flex: 0.48,
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#22c55e',
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 6,
  },
});
