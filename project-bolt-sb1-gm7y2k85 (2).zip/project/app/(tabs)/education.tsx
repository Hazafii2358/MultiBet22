import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { BookOpen, TriangleAlert as AlertTriangle, Shield, TrendingDown, Clock, DollarSign, Brain, Heart, Phone, CircleCheck as CheckCircle } from 'lucide-react-native';

export default function EducationScreen() {
  const [selectedTopic, setSelectedTopic] = useState('responsible');

  const topics = [
    { id: 'responsible', label: 'Jeu responsable', icon: Shield },
    { id: 'basics', label: 'Les bases', icon: BookOpen },
    { id: 'psychology', label: 'Psychologie', icon: Brain },
    { id: 'support', label: 'Aide & Support', icon: Heart },
  ];

  const responsibleGamingContent = {
    principles: [
      {
        title: 'Fixez vos limites',
        description: 'Déterminez à l\'avance combien vous êtes prêt à dépenser et respectez cette limite.',
        icon: DollarSign,
        color: '#22c55e',
      },
      {
        title: 'Gérez votre temps',
        description: 'Le jeu ne doit pas interférer avec vos responsabilités quotidiennes.',
        icon: Clock,
        color: '#f59e0b',
      },
      {
        title: 'Reconnaissez les signaux',
        description: 'Soyez attentif aux changements dans vos habitudes de jeu.',
        icon: AlertTriangle,
        color: '#eab308',
      },
    ],
    warningSignsTitle: 'Signaux d\'alarme',
    warningSigns: [
      'Jouer plus longtemps que prévu',
      'Augmenter les mises pour retrouver des sensations',
      'Emprunter de l\'argent pour jouer',
      'Mentir sur le temps ou l\'argent consacré au jeu',
      'Négliger le travail, la famille ou les amis',
      'Se sentir anxieux quand on ne peut pas jouer',
    ],
  };

  const basicsContent = {
    concepts: [
      {
        title: 'Probabilités et hasard',
        content: 'Comprendre que chaque tirage est indépendant et que les résultats passés n\'influencent pas les futurs.',
      },
      {
        title: 'Avantage de la maison',
        content: 'Toutes les plateformes ont un avantage mathématique. C\'est ainsi qu\'elles restent rentables.',
      },
      {
        title: 'Gestion de bankroll',
        content: 'Ne jamais jouer avec de l\'argent dont vous avez besoin pour vos dépenses essentielles.',
      },
      {
        title: 'Types de jeux',
        content: 'Chaque type de jeu a ses propres règles, cotes et stratégies. Apprenez avant de jouer.',
      },
    ],
  };

  const psychologyContent = {
    title: 'Comprendre la psychologie du jeu',
    points: [
      {
        concept: 'Renforcement intermittent',
        explanation: 'Les gains occasionnels créent une forte dépendance psychologique.',
      },
      {
        concept: 'Illusion de contrôle',
        explanation: 'Croire qu\'on peut influencer le hasard par ses actions ou décisions.',
      },
      {
        concept: 'Biais de confirmation',
        explanation: 'Se rappeler uniquement des gains et oublier les pertes.',
      },
      {
        concept: 'Escalade d\'engagement',
        explanation: 'Continuer à jouer pour récupérer les pertes précédentes.',
      },
    ],
  };

  const supportContent = {
    helplines: [
      {
        name: 'SOS Joueurs Guinée',
        phone: '+224 123 456 789',
        hours: '24h/24, 7j/7',
        free: true,
      },
      {
        name: 'Centre d\'aide addiction',
        phone: '+224 987 654 321',
        hours: 'Lun-Ven 8h-18h',
        free: true,
      },
    ],
    selfHelpTools: [
      'Auto-exclusion temporaire',
      'Limites de dépôt automatiques',
      'Rappels de temps de jeu',
      'Blocage d\'accès aux sites',
    ],
  };

  const renderResponsibleGaming = () => (
    <View>
      <Text style={styles.sectionTitle}>Principes du jeu responsable</Text>
      {responsibleGamingContent.principles.map((principle, index) => (
        <View key={index} style={styles.principleCard}>
          <View style={[styles.principleIcon, { backgroundColor: `${principle.color}20` }]}>
            <principle.icon size={24} color={principle.color} />
          </View>
          <View style={styles.principleContent}>
            <Text style={styles.principleTitle}>{principle.title}</Text>
            <Text style={styles.principleDescription}>{principle.description}</Text>
          </View>
        </View>
      ))}

      <Text style={[styles.sectionTitle, { marginTop: 30 }]}>
        {responsibleGamingContent.warningSignsTitle}
      </Text>
      <View style={styles.warningBox}>
        <AlertTriangle size={24} color="#dc2626" />
        <Text style={styles.warningTitle}>Attention si vous ressentez :</Text>
      </View>
      {responsibleGamingContent.warningSigns.map((sign, index) => (
        <View key={index} style={styles.warningItem}>
          <Text style={styles.warningBullet}>•</Text>
          <Text style={styles.warningText}>{sign}</Text>
        </View>
      ))}
    </View>
  );

  const renderBasics = () => (
    <View>
      <Text style={styles.sectionTitle}>Comprendre les jeux de hasard</Text>
      {basicsContent.concepts.map((concept, index) => (
        <View key={index} style={styles.conceptCard}>
          <Text style={styles.conceptTitle}>{concept.title}</Text>
          <Text style={styles.conceptContent}>{concept.content}</Text>
        </View>
      ))}
      
      <View style={styles.tipBox}>
        <CheckCircle size={20} color="#16a34a" />
        <Text style={styles.tipText}>
          Conseil : Considérez l'argent dépensé au jeu comme un coût de divertissement, 
          pas comme un investissement.
        </Text>
      </View>
    </View>
  );

  const renderPsychology = () => (
    <View>
      <Text style={styles.sectionTitle}>{psychologyContent.title}</Text>
      <Text style={styles.introText}>
        Comprendre les mécanismes psychologiques peut vous aider à garder le contrôle.
      </Text>
      
      {psychologyContent.points.map((point, index) => (
        <View key={index} style={styles.psychologyCard}>
          <Text style={styles.psychologyTitle}>{point.concept}</Text>
          <Text style={styles.psychologyExplanation}>{point.explanation}</Text>
        </View>
      ))}
    </View>
  );

  const renderSupport = () => (
    <View>
      <Text style={styles.sectionTitle}>Lignes d'aide</Text>
      {supportContent.helplines.map((helpline, index) => (
        <View key={index} style={styles.helplineCard}>
          <View style={styles.helplineHeader}>
            <Phone size={20} color="#dc2626" />
            <Text style={styles.helplineName}>{helpline.name}</Text>
          </View>
          <Text style={styles.helplinePhone}>{helpline.phone}</Text>
          <Text style={styles.helplineHours}>{helpline.hours}</Text>
          {helpline.free && (
            <View style={styles.freeBadge}>
              <Text style={styles.freeText}>Gratuit</Text>
            </View>
          )}
        </View>
      ))}

      <Text style={[styles.sectionTitle, { marginTop: 30 }]}>Outils d'auto-assistance</Text>
      {supportContent.selfHelpTools.map((tool, index) => (
        <View key={index} style={styles.toolItem}>
          <CheckCircle size={16} color="#16a34a" />
          <Text style={styles.toolText}>{tool}</Text>
        </View>
      ))}

      <TouchableOpacity style={styles.helpButton}>
        <Heart size={20} color="#ffffff" />
        <Text style={styles.helpButtonText}>Demander de l'aide</Text>
      </TouchableOpacity>
    </View>
  );

  const renderContent = () => {
    switch (selectedTopic) {
      case 'responsible':
        return renderResponsibleGaming();
      case 'basics':
        return renderBasics();
      case 'psychology':
        return renderPsychology();
      case 'support':
        return renderSupport();
      default:
        return renderResponsibleGaming();
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Éducation</Text>
          <Text style={styles.subtitle}>Apprenez à jouer de manière responsable</Text>
        </View>

        {/* Topic Selector */}
        <View style={styles.topicSelector}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {topics.map((topic) => (
              <TouchableOpacity
                key={topic.id}
                style={[
                  styles.topicButton,
                  selectedTopic === topic.id && styles.activeTopicButton
                ]}
                onPress={() => setSelectedTopic(topic.id)}
              >
                <topic.icon 
                  size={20} 
                  color={selectedTopic === topic.id ? '#ffffff' : '#6b7280'} 
                />
                <Text style={[
                  styles.topicText,
                  selectedTopic === topic.id && styles.activeTopicText
                ]}>
                  {topic.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Content */}
        <View style={styles.content}>
          {renderContent()}
        </View>

        {/* Emergency Contact */}
        <View style={styles.emergencySection}>
          <Text style={styles.emergencyTitle}>Besoin d'aide immédiate ?</Text>
          <TouchableOpacity style={styles.emergencyButton}>
            <Phone size={20} color="#ffffff" />
            <Text style={styles.emergencyText}>Appeler maintenant</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    marginTop: 4,
  },
  topicSelector: {
    paddingVertical: 20,
    paddingLeft: 20,
  },
  topicButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    borderRadius: 25,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  activeTopicButton: {
    backgroundColor: '#dc2626',
    borderColor: '#dc2626',
  },
  topicText: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 8,
    fontWeight: '500',
  },
  activeTopicText: {
    color: '#ffffff',
  },
  content: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 20,
  },
  principleCard: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  principleIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  principleContent: {
    flex: 1,
  },
  principleTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  principleDescription: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
  },
  warningBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fef2f2',
    padding: 16,
    borderRadius: 12,
    marginBottom: 15,
    borderLeftWidth: 4,
    borderLeftColor: '#dc2626',
  },
  warningTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#b91c1c',
    marginLeft: 12,
  },
  warningItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
    paddingLeft: 10,
  },
  warningBullet: {
    fontSize: 16,
    color: '#f59e0b',
    marginRight: 10,
    fontWeight: 'bold',
  },
  warningText: {
    fontSize: 14,
    color: '#374151',
    flex: 1,
    lineHeight: 20,
  },
  conceptCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  conceptTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  conceptContent: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
  },
  tipBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#f0fdf4',
    padding: 16,
    borderRadius: 12,
    marginTop: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#22c55e',
  },
  tipText: {
    fontSize: 14,
    color: '#15803d',
    marginLeft: 12,
    flex: 1,
    lineHeight: 20,
  },
  introText: {
    fontSize: 16,
    color: '#6b7280',
    marginBottom: 20,
    lineHeight: 24,
  },
  psychologyCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  psychologyTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#22c55e',
    marginBottom: 8,
  },
  psychologyExplanation: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
  },
  helplineCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  helplineHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  helplineName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 8,
  },
  helplinePhone: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#22c55e',
    marginBottom: 4,
  },
  helplineHours: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 8,
  },
  freeBadge: {
    backgroundColor: '#dcfce7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  freeText: {
    fontSize: 12,
    color: '#15803d',
    fontWeight: '600',
  },
  toolItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  toolText: {
    fontSize: 14,
    color: '#374151',
    marginLeft: 8,
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#22c55e',
    paddingVertical: 16,
    borderRadius: 12,
    marginTop: 20,
  },
  helpButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  emergencySection: {
    backgroundColor: '#22c55e',
    margin: 20,
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  emergencyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
    textAlign: 'center',
  },
  emergencyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  emergencyText: {
    color: '#22c55e',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
});