import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { UserProfile } from '@/lib/database.types';
import type { User, Session } from '@supabase/supabase-js';
import { AuthDiagnostic } from '@/lib/auth-diagnostic';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isReconnecting: boolean;
  connectionError: string | null;
  signUp: (email: string, password: string, fullName: string, phoneNumber?: string) => Promise<{ error?: string }>;
  signIn: (email: string, password: string) => Promise<{ error?: string }>;
  signOut: () => Promise<void>;
  forceReconnect: () => Promise<void>;
  clearConnectionError: () => void;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEYS = {
  LAST_EMAIL: 'multibet_last_email',
  AUTO_RECONNECT: 'multibet_auto_reconnect',
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  useEffect(() => {
    // Diagnostic au démarrage
    AuthDiagnostic.checkSupabaseConnection();
    
    // Initialiser la session avec gestion d'erreur
    initializeSession();

    // Écouter les changements d'authentification
    const subscription = supabase?.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state change:', event, session?.user?.id);
        
        setSession(session);
        setUser(session?.user ?? null);
        setConnectionError(null);
        
        if (session?.user) {
          await loadUserProfile(session.user.id);
          // Sauvegarder l'email pour la reconnexion automatique
          if (session.user.email) {
            await AsyncStorage.setItem(STORAGE_KEYS.LAST_EMAIL, session.user.email);
          }
        } else {
          setProfile(null);
          setLoading(false);
          // Rediriger vers l'écran de connexion quand la session est nulle
          if (event === 'SIGNED_OUT') {
            console.log('Session fermée, redirection vers /auth');
            router.replace('/auth');
          }
        }
        
        // Gérer les événements spéciaux
        if (event === 'SIGNED_OUT') {
          await AsyncStorage.removeItem(STORAGE_KEYS.AUTO_RECONNECT);
          setReconnectAttempts(0);
        }
        
        if (event === 'TOKEN_REFRESHED') {
          console.log('Token rafraîchi avec succès');
          setReconnectAttempts(0);
        }
      }
    );

    return () => subscription?.data?.subscription?.unsubscribe();
  }, []);

  const initializeSession = async () => {
    try {
      if (!supabase) {
        setLoading(false);
        return;
      }

      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) {
        console.error('Erreur récupération session:', error);
        setConnectionError(error.message);
        // Tenter une reconnexion automatique si possible
        await attemptAutoReconnect();
      } else {
        setSession(session);
        setUser(session?.user ?? null);
        if (session?.user) {
          await loadUserProfile(session.user.id);
        } else {
          setLoading(false);
        }
      }
    } catch (error) {
      console.error('Erreur initializeSession:', error);
      setConnectionError('Erreur de connexion');
      setLoading(false);
    }
  };

  const attemptAutoReconnect = async () => {
    try {
      const lastEmail = await AsyncStorage.getItem(STORAGE_KEYS.LAST_EMAIL);
      const autoReconnectData = await AsyncStorage.getItem(STORAGE_KEYS.AUTO_RECONNECT);
      
      if (lastEmail && autoReconnectData && reconnectAttempts < 3) {
        console.log('Tentative de reconnexion automatique...');
        setIsReconnecting(true);
        setReconnectAttempts(prev => prev + 1);
        
        // Attendre un peu avant de réessayer
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Tenter de rafraîchir la session
        const { error } = await supabase!.auth.refreshSession();
        if (error) {
          console.error('Échec reconnexion automatique:', error);
          setConnectionError('Reconnexion automatique échouée');
        }
      }
    } catch (error) {
      console.error('Erreur attemptAutoReconnect:', error);
    } finally {
      setIsReconnecting(false);
      setLoading(false);
    }
  };

  const loadUserProfile = async (userId: string) => {
    try {
      console.log('Chargement profil pour:', userId);
      
      if (!supabase) {
        console.warn('⚠️ Supabase non configuré - Impossible de charger le profil');
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Erreur chargement profil:', error);
        setConnectionError(`Erreur profil: ${error.message}`);
      } else if (data) {
        console.log('Profil chargé:', data);
        setProfile(data);
      } else {
        console.log('Aucun profil trouvé pour:', userId);
        // Si pas de profil en base, on peut créer un profil basique depuis les métadonnées
        if (user?.user_metadata?.full_name) {
          console.log('Création profil depuis métadonnées...');
          const { error: insertError } = await supabase
            .from('user_profiles')
            .insert({
              id: userId,
              email: user.email || '',
              full_name: user.user_metadata.full_name,
              phone: user.user_metadata.phone_number || null,
            });
          
          if (!insertError) {
            // Recharger le profil après création
            await loadUserProfile(userId);
            return;
          }
        }
      }
    } catch (error) {
      console.error('Erreur loadUserProfile:', error);
      setConnectionError('Erreur de chargement du profil');
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, fullName: string, phoneNumber?: string): Promise<{ error?: string }> => {
    try {
      console.log('Tentative d\'inscription:', { email, fullName, phoneNumber });
      
      if (!supabase) {
        console.error('❌ Client Supabase non disponible - Vérifiez votre configuration');
        return { error: 'Service non disponible. Veuillez configurer Supabase.' };
      }

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            phone_number: phoneNumber,
          },
        },
      });

      if (error) {
        console.error('Erreur Supabase signUp:', error);
        setConnectionError(error.message);
        return { error: error.message };
      }

      console.log('Inscription réussie:', data);
      // Sauvegarder pour la reconnexion automatique
      await AsyncStorage.setItem(STORAGE_KEYS.LAST_EMAIL, email);
      await AsyncStorage.setItem(STORAGE_KEYS.AUTO_RECONNECT, JSON.stringify({ email, timestamp: Date.now() }));
      setConnectionError(null);
      
      // Forcer la mise à jour de la session après inscription
      if (data.user) {
        setSession(data.session);
        setUser(data.user);
        // Charger le profil immédiatement après inscription
        if (data.session) {
          await loadUserProfile(data.user.id);
        }
      }
      
      return {};
    } catch (error) {
      console.error('Erreur signUp:', error);
      setConnectionError('Erreur lors de la création du compte');
      return { error: 'Erreur lors de la création du compte' };
    }
  };

  const signIn = async (email: string, password: string): Promise<{ error?: string }> => {
    try {
      console.log('Tentative de connexion:', { email });
      
      if (!supabase) {
        console.error('❌ Client Supabase non disponible - Vérifiez votre configuration');
        return { error: 'Service non disponible. Veuillez configurer Supabase.' };
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        console.error('Erreur Supabase signIn:', error);
        setConnectionError(error.message);
        return { error: error.message };
      }

      console.log('Connexion réussie');
      // Sauvegarder pour la reconnexion automatique
      await AsyncStorage.setItem(STORAGE_KEYS.LAST_EMAIL, email);
      await AsyncStorage.setItem(STORAGE_KEYS.AUTO_RECONNECT, JSON.stringify({ email, timestamp: Date.now() }));
      setConnectionError(null);
      setReconnectAttempts(0);
      return {};
    } catch (error) {
      console.error('Erreur signIn:', error);
      setConnectionError('Erreur lors de la connexion');
      return { error: 'Erreur lors de la connexion' };
    }
  };

  const signOut = async () => {
    console.log('🔴 DÉCONNEXION DÉMARRÉE');
    
    try {
      // 1. Déconnexion Supabase d'abord
      if (supabase) {
        const { error } = await supabase.auth.signOut();
        if (error) {
          console.error('Erreur Supabase signOut:', error);
        }
      }
      
      // 2. Nettoyer le stockage
      await AsyncStorage.multiRemove([STORAGE_KEYS.AUTO_RECONNECT, STORAGE_KEYS.LAST_EMAIL]);
      
      // 3. Nettoyer l'état local
      setSession(null);
      setUser(null);
      setProfile(null);
      setConnectionError(null);
      setReconnectAttempts(0);
      setLoading(false);
      
      console.log('✅ Déconnexion complète');
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
      // Même en cas d'erreur, on nettoie l'état local
      setSession(null);
      setUser(null);
      setProfile(null);
      setConnectionError(null);
      setReconnectAttempts(0);
      setLoading(false);
    }
  };

  const forceReconnect = async () => {
    try {
      setIsReconnecting(true);
      setConnectionError(null);
      
      if (!supabase) {
        setConnectionError('Service non disponible');
        return;
      }

      // Tenter de rafraîchir la session
      const { error } = await supabase.auth.refreshSession();
      
      if (error) {
        console.error('Erreur refresh session:', error);
        setConnectionError('Impossible de se reconnecter');
        
        // Si le refresh échoue, déconnecter complètement
        await signOut();
      } else {
        console.log('Reconnexion réussie');
        setReconnectAttempts(0);
      }
    } catch (error) {
      console.error('Erreur forceReconnect:', error);
      setConnectionError('Erreur de reconnexion');
    } finally {
      setIsReconnecting(false);
    }
  };

  const clearConnectionError = () => {
    setConnectionError(null);
  };

  const updateProfile = async (updates: Partial<UserProfile>): Promise<{ error?: string }> => {
    try {
      if (!supabase || !user) {
        return { error: 'Non connecté' };
      }

      const { error } = await supabase
        .from('user_profiles')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', user.id);

      if (error) {
        setConnectionError(error.message);
        return { error: error.message };
      }

      // Recharger le profil
      await loadUserProfile(user.id);
      setConnectionError(null);
      return {};
    } catch (error) {
      console.error('Erreur updateProfile:', error);
      setConnectionError('Erreur lors de la mise à jour du profil');
      return { error: 'Erreur lors de la mise à jour du profil' };
    }
  };

  const value = {
    session,
    user,
    profile,
    loading,
    isReconnecting,
    connectionError,
    signUp,
    signIn,
    signOut,
    forceReconnect,
    clearConnectionError,
    updateProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}