import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Rect, Circle, Path } from 'react-native-svg';

interface MultiBetLogoProps {
  width?: number;
  height?: number;
}

export default function MultiBetLogo({ width = 180, height = 40 }: MultiBetLogoProps) {
  const iconSize = height;
  
  return (
    <View style={styles.container}>
      {/* Logo Icon */}
      <View style={styles.iconContainer}>
        <Svg width={iconSize} height={iconSize} viewBox="0 0 100 100">
          {/* Background rounded rectangle - Green */}
          <Rect
            x="10"
            y="10"
            width="80"
            height="80"
            rx="20"
            ry="20"
            fill="#22c55e"
          />
          
          {/* White circle */}
          <Circle
            cx="35"
            cy="50"
            r="12"
            fill="white"
          />
          
          {/* Green inner circle */}
          <Circle
            cx="35"
            cy="50"
            r="6"
            fill="#22c55e"
          />
          
          {/* White arrow pointing right */}
          <Path
            d="M 55 40 L 70 50 L 55 60 L 58 63 L 78 50 L 58 37 Z"
            fill="white"
          />
        </Svg>
      </View>
      
      {/* Text Logo */}
      <View style={styles.textContainer}>
        <Text style={styles.multiBetText}>MultiBet</Text>
        <Text style={styles.guineeText}>GUINÉE</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    marginRight: 12,
  },
  textContainer: {
    flexDirection: 'column',
  },
  multiBetText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    letterSpacing: -0.5,
  },
  guineeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6b7280',
    letterSpacing: 2,
    marginTop: -2,
  },
});