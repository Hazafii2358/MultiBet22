import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { WifiOff, RefreshCw, X } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';

export default function ConnectionStatus() {
  const { connectionError, isReconnecting, forceReconnect, clearConnectionError } = useAuth();

  if (!connectionError && !isReconnecting) {
    return null;
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {isReconnecting ? (
          <>
            <ActivityIndicator size="small" color="#ffffff" />
            <Text style={styles.text}>Reconnexion en cours...</Text>
          </>
        ) : (
          <>
            <WifiOff size={20} color="#ffffff" />
            <Text style={styles.text}>
              {connectionError || 'Problème de connexion'}
            </Text>
            <TouchableOpacity
              style={styles.retryButton}
              onPress={forceReconnect}
            >
              <RefreshCw size={16} color="#ffffff" />
              <Text style={styles.retryText}>Réessayer</Text>
            </TouchableOpacity>
          </>
        )}
        
        {!isReconnecting && (
          <TouchableOpacity
            style={styles.closeButton}
            onPress={clearConnectionError}
          >
            <X size={16} color="#ffffff" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: '#dc2626',
    zIndex: 1000,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  text: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '500',
    marginLeft: 8,
    flex: 1,
    textAlign: 'center',
  },
  retryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginLeft: 8,
  },
  retryText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  closeButton: {
    padding: 4,
    marginLeft: 8,
  },
});