import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { Bug, Play, RefreshCw } from 'lucide-react-native';
import { AuthDiagnostic } from '@/lib/auth-diagnostic';
import { supabase } from '@/lib/supabase';

interface AuthDebugPanelProps {
  visible: boolean;
  onClose: () => void;
}

export default function AuthDebugPanel({ visible, onClose }: AuthDebugPanelProps) {
  const [diagnosticResult, setDiagnosticResult] = useState<string>('');
  const [loading, setLoading] = useState(false);

  if (!visible) return null;

  const runDiagnostic = async () => {
    setLoading(true);
    setDiagnosticResult('Exécution du diagnostic...\n');
    
    try {
      // Capturer les logs console
      const originalLog = console.log;
      const originalError = console.error;
      let logs = '';
      
      console.log = (...args) => {
        logs += args.join(' ') + '\n';
        originalLog(...args);
      };
      
      console.error = (...args) => {
        logs += 'ERROR: ' + args.join(' ') + '\n';
        originalError(...args);
      };
      
      await AuthDiagnostic.checkSupabaseConnection();
      
      // Restaurer les fonctions console
      console.log = originalLog;
      console.error = originalError;
      
      setDiagnosticResult(logs);
    } catch (error) {
      setDiagnosticResult(`Erreur diagnostic: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const testSignUp = async () => {
    setLoading(true);
    const testEmail = `test${Date.now()}@example.com`;
    const testPassword = 'testpassword123';
    const testName = 'Test User';
    
    try {
      const result = await AuthDiagnostic.testSignUp(testEmail, testPassword, testName);
      Alert.alert(
        'Test Inscription',
        result.success ? 'Inscription test réussie' : `Erreur: ${result.error}`
      );
    } catch (error) {
      Alert.alert('Erreur', `Test échoué: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const checkDatabase = async () => {
    setLoading(true);
    try {
      if (!supabase) {
        Alert.alert('Erreur', 'Client Supabase non initialisé');
        return;
      }

      // Vérifier la fonction de diagnostic
      const { data, error } = await supabase.rpc('debug_user_creation');
      
      if (error) {
        Alert.alert('Erreur DB', error.message);
      } else {
        Alert.alert(
          'État de la DB',
          `Trigger: ${data[0].trigger_exists ? '✅' : '❌'}\n` +
          `Fonction: ${data[0].function_exists ? '✅' : '❌'}\n` +
          `RLS: ${data[0].rls_enabled ? '✅' : '❌'}\n` +
          `Politiques: ${data[0].policies_count}`
        );
      }
    } catch (error) {
      Alert.alert('Erreur', `Vérification échouée: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.overlay}>
      <View style={styles.panel}>
        <View style={styles.header}>
          <Text style={styles.title}>Debug Authentification</Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Text style={styles.closeText}>✕</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.actionButton, loading && styles.disabledButton]}
            onPress={runDiagnostic}
            disabled={loading}
          >
            <Bug size={16} color="#ffffff" />
            <Text style={styles.actionText}>Diagnostic complet</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.secondaryButton, loading && styles.disabledButton]}
            onPress={checkDatabase}
            disabled={loading}
          >
            <RefreshCw size={16} color="#22c55e" />
            <Text style={[styles.actionText, { color: '#22c55e' }]}>État DB</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.warningButton, loading && styles.disabledButton]}
            onPress={testSignUp}
            disabled={loading}
          >
            <Play size={16} color="#ffffff" />
            <Text style={styles.actionText}>Test inscription</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.resultContainer}>
          <Text style={styles.resultText}>
            {diagnosticResult || 'Cliquez sur "Diagnostic complet" pour commencer...'}
          </Text>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  panel: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    margin: 20,
    maxHeight: '80%',
    width: '90%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  closeButton: {
    padding: 8,
  },
  closeText: {
    fontSize: 18,
    color: '#6b7280',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#22c55e',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 2,
    justifyContent: 'center',
  },
  secondaryButton: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#22c55e',
  },
  warningButton: {
    backgroundColor: '#f59e0b',
  },
  disabledButton: {
    opacity: 0.5,
  },
  actionText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  resultContainer: {
    backgroundColor: '#f9fafb',
    borderRadius: 8,
    padding: 12,
    maxHeight: 300,
  },
  resultText: {
    fontSize: 12,
    color: '#374151',
    fontFamily: 'monospace',
  },
});