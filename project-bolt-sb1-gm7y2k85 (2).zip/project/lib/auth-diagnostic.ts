import { supabase } from './supabase';

export class AuthDiagnostic {
  static async checkSupabaseConnection() {
    console.log('=== DIAGNOSTIC SUPABASE ===');
    
    // 1. Vérifier la configuration
    console.log('1. Configuration Supabase:');
    console.log('URL:', process.env.EXPO_PUBLIC_SUPABASE_URL);
    console.log('Anon Key présente:', !!process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);
    console.log('Client initialisé:', !!supabase);
    
    if (!supabase) {
      console.error('❌ Client Supabase non initialisé');
      return false;
    }

    try {
      // 2. Test de connexion basique
      console.log('\n2. Test de connexion:');
      const { data, error } = await supabase.from('platforms').select('count').limit(1);
      if (error) {
        console.error('❌ Erreur connexion DB:', error);
      } else {
        console.log('✅ Connexion DB réussie');
      }

      // 3. Vérifier la session actuelle
      console.log('\n3. Session actuelle:');
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) {
        console.error('❌ Erreur récupération session:', sessionError);
      } else {
        console.log('Session:', sessionData.session ? 'Connecté' : 'Non connecté');
        if (sessionData.session) {
          console.log('User ID:', sessionData.session.user.id);
          console.log('Email:', sessionData.session.user.email);
        }
      }

      // 4. Vérifier les politiques RLS
      console.log('\n4. Test des politiques RLS:');
      try {
        const { data: profileData, error: profileError } = await supabase
          .from('user_profiles')
          .select('*')
          .limit(1);
        
        if (profileError) {
          console.error('❌ Erreur accès user_profiles:', profileError);
        } else {
          console.log('✅ Accès user_profiles autorisé');
        }
      } catch (err) {
        console.error('❌ Erreur test RLS:', err);
      }

      return true;
    } catch (error) {
      console.error('❌ Erreur générale:', error);
      return false;
    }
  }

  static async testSignUp(email: string, password: string, fullName: string) {
    console.log('\n=== TEST INSCRIPTION ===');
    console.log('Email:', email);
    console.log('Nom complet:', fullName);
    
    if (!supabase) {
      console.error('❌ Client Supabase non disponible');
      return { success: false, error: 'Client non initialisé' };
    }

    try {
      // Test d'inscription
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      });

      if (error) {
        console.error('❌ Erreur inscription:', error);
        return { success: false, error: error.message };
      }

      console.log('✅ Inscription réussie');
      console.log('User ID:', data.user?.id);
      console.log('Email confirmé:', data.user?.email_confirmed_at ? 'Oui' : 'Non');
      
      // Vérifier si le profil a été créé
      if (data.user) {
        setTimeout(async () => {
          const { data: profileData, error: profileError } = await supabase
            .from('user_profiles')
            .select('*')
            .eq('id', data.user!.id)
            .single();

          if (profileError) {
            console.error('❌ Profil non créé:', profileError);
          } else {
            console.log('✅ Profil créé automatiquement:', profileData);
          }
        }, 2000);
      }

      return { success: true, data };
    } catch (error) {
      console.error('❌ Erreur test inscription:', error);
      return { success: false, error: 'Erreur inattendue' };
    }
  }

  static async testSignIn(email: string, password: string) {
    console.log('\n=== TEST CONNEXION ===');
    console.log('Email:', email);
    
    if (!supabase) {
      console.error('❌ Client Supabase non disponible');
      return { success: false, error: 'Client non initialisé' };
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        console.error('❌ Erreur connexion:', error);
        return { success: false, error: error.message };
      }

      console.log('✅ Connexion réussie');
      console.log('User ID:', data.user?.id);
      
      // Vérifier le profil
      if (data.user) {
        const { data: profileData, error: profileError } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();

        if (profileError) {
          console.error('❌ Profil non trouvé:', profileError);
        } else {
          console.log('✅ Profil chargé:', profileData);
        }
      }

      return { success: true, data };
    } catch (error) {
      console.error('❌ Erreur test connexion:', error);
      return { success: false, error: 'Erreur inattendue' };
    }
  }
}