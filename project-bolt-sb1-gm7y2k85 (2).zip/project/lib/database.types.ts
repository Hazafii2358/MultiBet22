export interface Database {
  public: {
    Tables: {
      platforms: {
        Row: {
          id: string;
          name: string;
          category: string;
          description: string;
          rating: number;
          users_count: string;
          founded: string;
          license: string;
          features: string[];
          current_promotions: string[];
          payment_methods: string[];
          bonus_welcome: string;
          best_odds: string;
          jackpot: string;
          processing_time: string;
          championships: string[];
          championship_odds: any;
          championship_links: any;
          specialties: string;
          color: string;
          website: string;
          logo_path: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          category: string;
          description: string;
          rating?: number;
          users_count?: string;
          founded?: string;
          license?: string;
          features?: string[];
          current_promotions?: string[];
          payment_methods?: string[];
          bonus_welcome?: string;
          best_odds?: string;
          jackpot?: string;
          processing_time?: string;
          championships?: string[];
          championship_odds?: any;
          championship_links?: any;
          specialties?: string;
          color?: string;
          website?: string;
          logo_path?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          category?: string;
          description?: string;
          rating?: number;
          users_count?: string;
          founded?: string;
          license?: string;
          features?: string[];
          current_promotions?: string[];
          payment_methods?: string[];
          bonus_welcome?: string;
          best_odds?: string;
          jackpot?: string;
          processing_time?: string;
          championships?: string[];
          championship_odds?: any;
          championship_links?: any;
          specialties?: string;
          color?: string;
          website?: string;
          logo_path?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      user_profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          phone: string | null;
          date_of_birth: string | null;
          preferred_platforms: string[];
          total_spent: number;
          total_won: number;
          total_bets: number;
          win_rate: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name: string;
          phone?: string;
          date_of_birth?: string | null;
          preferred_platforms?: string[];
          total_spent?: number;
          total_won?: number;
          total_bets?: number;
          win_rate?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          phone?: string | null;
          date_of_birth?: string | null;
          preferred_platforms?: string[];
          total_spent?: number;
          total_won?: number;
          total_bets?: number;
          win_rate?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}

export type Platform = Database['public']['Tables']['platforms']['Row'];
export type UserProfile = Database['public']['Tables']['user_profiles']['Row'];