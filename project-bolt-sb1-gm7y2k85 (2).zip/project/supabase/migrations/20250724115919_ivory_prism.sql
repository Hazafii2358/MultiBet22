/*
  # Création du système d'authentification et profils utilisateurs

  1. Nouvelles Tables
    - `user_profiles`
      - `id` (uuid, clé primaire liée à auth.users)
      - `email` (text, unique, non null)
      - `full_name` (text, non null)
      - `phone` (text, optionnel)
      - `date_of_birth` (date, optionnel)
      - `preferred_platforms` (text array, défaut vide)
      - `total_spent` (numeric, défaut 0)
      - `total_won` (numeric, défaut 0)
      - `total_bets` (integer, défaut 0)
      - `win_rate` (numeric, défaut 0)
      - `created_at` (timestamp, défaut now())
      - `updated_at` (timestamp, défaut now())

  2. Sécurité
    - Activer RLS sur la table `user_profiles`
    - Politique pour lecture des données personnelles
    - Politique pour mise à jour des données personnelles
    - Politique pour insertion lors de l'inscription

  3. Automatisation
    - Trigger pour création automatique du profil lors de l'inscription
    - Trigger pour mise à jour automatique du champ updated_at
*/

-- Créer la table des profils utilisateurs
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  phone text,
  date_of_birth date,
  preferred_platforms text[] DEFAULT '{}',
  total_spent numeric DEFAULT 0,
  total_won numeric DEFAULT 0,
  total_bets integer DEFAULT 0,
  win_rate numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Activer la sécurité au niveau des lignes (RLS)
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Politique pour que les utilisateurs puissent lire leurs propres données
CREATE POLICY "Users can read own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Politique pour que les utilisateurs puissent mettre à jour leurs propres données
CREATE POLICY "Users can update own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Politique pour l'insertion automatique lors de l'inscription
CREATE POLICY "Users can insert own profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Fonction pour créer automatiquement un profil lors de l'inscription
CREATE OR REPLACE FUNCTION create_user_profile()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Utilisateur')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger pour créer automatiquement le profil
DROP TRIGGER IF EXISTS create_user_profile_trigger ON auth.users;
CREATE TRIGGER create_user_profile_trigger
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_user_profile();

-- Fonction pour mettre à jour automatiquement updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger pour updated_at
DROP TRIGGER IF EXISTS update_user_profiles_updated_at ON user_profiles;
CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();