/*
  # Create platforms table

  1. New Tables
    - `platforms`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `category` (text)
      - `description` (text)
      - `rating` (numeric)
      - `users_count` (text)
      - `founded` (text)
      - `license` (text)
      - `features` (text array)
      - `current_promotions` (text array)
      - `payment_methods` (text array)
      - `bonus_welcome` (text)
      - `best_odds` (text)
      - `jackpot` (text)
      - `processing_time` (text)
      - `championships` (text array)
      - `championship_odds` (jsonb)
      - `championship_links` (jsonb)
      - `specialties` (text)
      - `color` (text)
      - `website` (text)
      - `logo_path` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `platforms` table
    - Add policy for public read access
*/

CREATE TABLE IF NOT EXISTS platforms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  rating numeric DEFAULT 0,
  users_count text DEFAULT '0',
  founded text DEFAULT '',
  license text DEFAULT '',
  features text[] DEFAULT '{}',
  current_promotions text[] DEFAULT '{}',
  payment_methods text[] DEFAULT '{}',
  bonus_welcome text DEFAULT '',
  best_odds text DEFAULT '',
  jackpot text DEFAULT '',
  processing_time text DEFAULT '',
  championships text[] DEFAULT '{}',
  championship_odds jsonb DEFAULT '{}',
  championship_links jsonb DEFAULT '{}',
  specialties text DEFAULT '',
  color text DEFAULT '#22c55e',
  website text DEFAULT '',
  logo_path text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE platforms ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Platforms are publicly readable"
  ON platforms
  FOR SELECT
  TO public
  USING (true);

-- Insert platform data
INSERT INTO platforms (
  name, category, description, rating, users_count, founded, license,
  features, current_promotions, payment_methods, bonus_welcome,
  best_odds, jackpot, processing_time, championships, championship_odds,
  championship_links, specialties, color, website, logo_path
) VALUES 
(
  '1xBet',
  'sport',
  'Plateforme internationale de paris sportifs avec une large couverture',
  4.6,
  '1M+',
  '2007',
  'Curaçao eGaming',
  ARRAY['Plus de 1000 événements par jour', 'Paris en direct (live betting)', 'Streaming en direct', 'Application mobile', 'Bonus de bienvenue généreux'],
  ARRAY['100% de bonus jusqu''à 200,000 GNF', 'Paris gratuits chaque vendredi', 'Cashback sur les paris perdants'],
  ARRAY['Orange Money', 'MTN Money', 'Visa', 'Mastercard'],
  '100% jusqu''à 200k GNF',
  'Jusqu''à 1.95',
  '890M GNF',
  '2h',
  ARRAY['Premier League', 'LaLiga', 'Champions League', 'Europa League', 'Bundesliga', 'Serie A'],
  '{"Premier League": 1.93, "LaLiga": 1.95, "Champions League": 1.96, "Europa League": 1.94, "Bundesliga": 1.92, "Serie A": 1.94}',
  '{"Premier League": "https://1xbet.com.gn/fr/champs/88637", "LaLiga": "https://1xbet.com.gn/fr/champs/127733", "Champions League": "https://1xbet.com.gn/fr/live/football/champions-league", "Europa League": "https://1xbet.com.gn/fr/live/football/europa-league", "Bundesliga": "https://1xbet.com.gn/fr/champs/96463", "Serie A": "https://1xbet.com.gn/fr/champs/110163"}',
  'Spécialiste football anglais et européen + Paris en direct',
  '#f59e0b',
  'https://1xbet.com.gn/fr',
  '1xbet.png'
),
(
  'Genus Bet',
  'sport',
  'Spécialiste des compétitions africaines et internationales',
  4.3,
  '150k+',
  '2021',
  'Bénin Gaming Commission',
  ARRAY['Focus sur le football africain', 'Cotes compétitives', 'Paris combinés spéciaux', 'Analyses d''experts', 'Communauté de parieurs'],
  ARRAY['Bonus de bienvenue 200%', 'Super cotes sur la CAN', 'Remboursement paris perdants'],
  ARRAY['Orange Money', 'MTN Money'],
  '200% jusqu''à 150k GNF',
  'Jusqu''à 1.92',
  '650M GNF',
  '1h',
  ARRAY['Ligue 1', 'CAN 2024', 'Ligue Guinéenne', 'Championnat UEMOA', 'Coupe CAF'],
  '{"Ligue 1": 1.92, "CAN 2024": 1.88, "Ligue Guinéenne": 1.85, "Championnat UEMOA": 1.87, "Coupe CAF": 1.89}',
  '{"Ligue 1": "https://genusbet.com/football/france/ligue-1", "CAN 2024": "https://genusbet.com/football/africa/can", "Ligue Guinéenne": "https://genusbet.com/football/guinea/championnat", "Championnat UEMOA": "https://genusbet.com/football/africa/uemoa", "Coupe CAF": "https://genusbet.com/football/africa/caf"}',
  'Spécialiste football africain et français',
  '#22c55e',
  'https://genusbet.com',
  'yellowbet.png'
),
(
  'Yellow Bet',
  'casino',
  'Casino en ligne avec des jeux de qualité et jackpots progressifs',
  4.5,
  '250k+',
  '2020',
  'Malta Gaming Authority',
  ARRAY['Plus de 500 jeux de casino', 'Jackpots progressifs', 'Tables de jeu en direct', 'Jeux exclusifs', 'Programme VIP'],
  ARRAY['150% de bonus + 50 tours gratuits', 'Tournois hebdomadaires', 'Cashback quotidien 10%'],
  ARRAY['Orange Money', 'MTN Money', 'Bitcoin'],
  '150% jusqu''à 300k GNF',
  'Jusqu''à 1.88',
  '2.1B GNF',
  '1h30',
  ARRAY['Tournois Poker', 'Jackpot Progressif', 'Concours Hebdo', 'Machines à Sous VIP'],
  '{"Tournois Poker": 1.88, "Jackpot Progressif": 1.85, "Concours Hebdo": 1.82, "Machines à Sous VIP": 1.86}',
  '{"Tournois Poker": "https://yellowbet.gn/poker-tournaments", "Jackpot Progressif": "https://yellowbet.gn/progressive-jackpot", "Concours Hebdo": "https://yellowbet.gn/weekly-contests", "Machines à Sous VIP": "https://yellowbet.gn/vip-slots"}',
  'Spécialiste casino en ligne et jeux de table',
  '#eab308',
  'https://yellowbet.gn',
  'geniusbet.png'
),
(
  'Guinée Millions',
  'loterie',
  'La plateforme officielle de loterie de la République de Guinée',
  4.8,
  '500k+',
  '2018',
  'Gouvernement de Guinée',
  ARRAY['Loterie nationale officielle', 'Paiement via Orange Money', 'Support client 24/7', 'Retraits instantanés', 'Interface en français'],
  ARRAY['Tirage spécial 5 milliards ce weekend', 'Bonus de fidélité 10% chaque mois', 'Réduction sur les grilles multiples'],
  ARRAY['Orange Money', 'MTN Money', 'Moov Money'],
  '50% jusqu''à 100k GNF',
  'Jusqu''à 1.85',
  '2.5B GNF',
  '30min',
  ARRAY['Loterie Nationale', 'Super Loto', 'Jeux Flash', 'Bingo'],
  '{"Loterie Nationale": 1.85, "Super Loto": 1.80, "Jeux Flash": 1.75, "Bingo": 1.78}',
  '{"Loterie Nationale": "https://guineemillions.net/loterie", "Super Loto": "https://guineemillions.net/superloto", "Jeux Flash": "https://guineemillions.net/flash", "Bingo": "https://guineemillions.net/bingo"}',
  'Spécialiste loterie et jeux de hasard',
  '#22c55e',
  'https://guineemillions.net',
  'guinee-millions.png'
),
(
  'Lonagui',
  'loterie',
  'Loterie nationale guinéenne avec jeux de bingo en ligne',
  4.2,
  '120k+',
  '1980',
  'Gouvernement de Guinée',
  ARRAY['Loterie traditionnelle', 'Bingo en ligne', 'Jeux de grattage', 'Héritage culturel', 'Simplicité d''utilisation'],
  ARRAY['Cashback 10% tous les dimanches', 'Grilles de bingo gratuites', 'Tirage bonus mensuel'],
  ARRAY['Orange Money', 'MTN Money', 'Moov Money'],
  '30% jusqu''à 75k GNF',
  'Jusqu''à 1.80',
  '450M GNF',
  '45min',
  ARRAY['Bingo National', 'Loto 6/49', 'Super Grattage', 'Bingo Express'],
  '{"Bingo National": 1.80, "Loto 6/49": 1.75, "Super Grattage": 1.70, "Bingo Express": 1.72}',
  '{"Bingo National": "https://lonagui.gn/bingo-national", "Loto 6/49": "https://lonagui.gn/loto-649", "Super Grattage": "https://lonagui.gn/grattage", "Bingo Express": "https://lonagui.gn/bingo-express"}',
  'Spécialiste jeux traditionnels guinéens',
  '#7c3aed',
  'https://lonagui.gn',
  'lonagui.jpg'
),
(
  'Guinée Games',
  'casino',
  'Plateforme dédiée aux jeux traditionnels guinéens modernisés',
  4.4,
  '180k+',
  '2019',
  'Ministère des Sports GN',
  ARRAY['Jeux traditionnels guinéens', 'Cagnotte communautaire', 'Mini-jeux quotidiens', 'Défis entre amis', 'Interface culturellement adaptée'],
  ARRAY['Pari gratuit de 50,000 GNF', 'Double points le weekend', 'Concours mensuel communautaire'],
  ARRAY['Orange Money', 'MTN Money', 'Moov Money'],
  '150% jusqu''à 300k GNF',
  'Jusqu''à 1.88',
  '180M GNF',
  '1h30',
  ARRAY['Jeux Traditionnels', 'Cagnotte Communautaire', 'Mini-Jeux', 'Défis Amis'],
  '{"Jeux Traditionnels": 1.88, "Cagnotte Communautaire": 1.85, "Mini-Jeux": 1.82, "Défis Amis": 1.86}',
  '{"Jeux Traditionnels": "https://guineegames.com/traditional", "Cagnotte Communautaire": "https://guineegames.com/community", "Mini-Jeux": "https://guineegames.com/mini-games", "Défis Amis": "https://guineegames.com/challenges"}',
  'Spécialiste jeux traditionnels guinéens modernisés',
  '#059669',
  'https://guineegames.com',
  'guinee-games.png'
);