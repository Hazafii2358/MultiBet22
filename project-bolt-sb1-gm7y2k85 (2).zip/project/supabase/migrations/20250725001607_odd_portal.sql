/*
  # Add missing RLS policies for user_profiles table

  1. Security Updates
    - Add INSERT policy for user_profiles table to allow authenticated users to create their own profile
    - Ensure users can only insert profiles with their own user ID

  2. Changes
    - Add policy "Users can insert own profile" for INSERT operations
    - Policy allows authenticated users to insert only when auth.uid() matches the profile ID
*/

-- Add INSERT policy for user_profiles table
CREATE POLICY "Users can insert own profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);