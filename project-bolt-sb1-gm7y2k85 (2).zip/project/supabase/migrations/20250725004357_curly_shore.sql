/*
  # Fix user_profiles RLS policies

  1. Security Updates
    - Drop existing conflicting policies on user_profiles table
    - Create new comprehensive policies for INSERT, SELECT, and UPDATE operations
    - Ensure authenticated users can create their own profile during signup
    - Maintain security by restricting access to own data only

  2. Policy Details
    - INSERT policy: Allows authenticated users to create their own profile
    - SELECT policy: Allows users to read their own profile data
    - UPDATE policy: Allows users to update their own profile data
*/

-- Drop existing policies that might be conflicting
DROP POLICY IF EXISTS "user_profiles_insert_policy" ON user_profiles;
DROP POLICY IF EXISTS "user_profiles_select_own" ON user_profiles;
DROP POLICY IF EXISTS "user_profiles_update_own" ON user_profiles;

-- Create comprehensive RLS policies for user_profiles
CREATE POLICY "Allow authenticated users to create their own profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Allow users to read their own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Allow users to update their own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Ensure RLS is enabled
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;