/*
  # Debug et correction de la création automatique des profils utilisateur

  1. Diagnostic
    - Vérification des triggers existants
    - Test des politiques RLS
    - Validation de la structure de la table

  2. Corrections
    - Recréation du trigger de création automatique
    - Mise à jour des politiques RLS
    - Ajout de logs pour le debugging
*/

-- Supprimer les anciens triggers et fonctions
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Créer une fonction de diagnostic
CREATE OR REPLACE FUNCTION public.debug_user_creation()
RETURNS TABLE(
  trigger_exists boolean,
  function_exists boolean,
  rls_enabled boolean,
  policies_count bigint
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    EXISTS(
      SELECT 1 FROM information_schema.triggers 
      WHERE trigger_name = 'on_auth_user_created'
    ) as trigger_exists,
    EXISTS(
      SELECT 1 FROM information_schema.routines 
      WHERE routine_name = 'handle_new_user'
    ) as function_exists,
    (
      SELECT relrowsecurity 
      FROM pg_class 
      WHERE relname = 'user_profiles'
    ) as rls_enabled,
    (
      SELECT COUNT(*) 
      FROM pg_policies 
      WHERE tablename = 'user_profiles'
    ) as policies_count;
END;
$$;

-- Fonction améliorée pour créer un profil utilisateur
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_full_name text;
BEGIN
  -- Log pour debugging
  RAISE LOG 'Création profil pour utilisateur: %', NEW.id;
  
  -- Extraire le nom complet des métadonnées
  user_full_name := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    'Utilisateur'
  );
  
  -- Log du nom extrait
  RAISE LOG 'Nom extrait: %', user_full_name;
  
  -- Insérer le profil utilisateur avec gestion d'erreur
  BEGIN
    INSERT INTO public.user_profiles (
      id,
      email,
      full_name,
      phone,
      date_of_birth,
      preferred_platforms,
      total_spent,
      total_won,
      total_bets,
      win_rate,
      created_at,
      updated_at
    ) VALUES (
      NEW.id,
      NEW.email,
      user_full_name,
      NULL,
      NULL,
      ARRAY[]::text[],
      0,
      0,
      0,
      0,
      NOW(),
      NOW()
    );
    
    RAISE LOG 'Profil créé avec succès pour: %', NEW.id;
    
  EXCEPTION WHEN OTHERS THEN
    RAISE LOG 'Erreur création profil: % - %', SQLSTATE, SQLERRM;
    -- Ne pas faire échouer l'inscription si la création du profil échoue
  END;
  
  RETURN NEW;
END;
$$;

-- Créer le trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- S'assurer que RLS est activé
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Supprimer toutes les anciennes politiques
DROP POLICY IF EXISTS "Users can insert their own profile" ON user_profiles;
DROP POLICY IF EXISTS "Users can read their own profile" ON user_profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON user_profiles;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON user_profiles;
DROP POLICY IF EXISTS "Enable read for users based on user_id" ON user_profiles;
DROP POLICY IF EXISTS "Enable update for users based on user_id" ON user_profiles;

-- Créer des politiques RLS simplifiées et robustes
CREATE POLICY "Allow authenticated users to insert their own profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Allow users to read their own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Allow users to update their own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Fonction pour tester la création manuelle d'un profil
CREATE OR REPLACE FUNCTION public.test_profile_creation(
  test_user_id uuid,
  test_email text,
  test_full_name text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  BEGIN
    INSERT INTO public.user_profiles (
      id,
      email,
      full_name,
      phone,
      date_of_birth,
      preferred_platforms,
      total_spent,
      total_won,
      total_bets,
      win_rate,
      created_at,
      updated_at
    ) VALUES (
      test_user_id,
      test_email,
      test_full_name,
      NULL,
      NULL,
      ARRAY[]::text[],
      0,
      0,
      0,
      0,
      NOW(),
      NOW()
    );
    
    RETURN true;
  EXCEPTION WHEN OTHERS THEN
    RAISE LOG 'Erreur test création profil: % - %', SQLSTATE, SQLERRM;
    RETURN false;
  END;
END;
$$;