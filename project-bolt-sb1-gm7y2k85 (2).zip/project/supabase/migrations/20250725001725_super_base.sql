/*
  # Fix user_profiles table defaults

  1. Changes
    - Add DEFAULT now() to created_at column if not already set
    - Add DEFAULT now() to updated_at column if not already set
  
  2. Security
    - No changes to existing RLS policies
  
  This migration fixes the "Database error saving new user" issue by ensuring
  timestamp columns have proper default values when inserting new user profiles.
*/

-- Add default value for created_at if it doesn't already have one
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' 
    AND column_name = 'created_at' 
    AND column_default IS NOT NULL
  ) THEN
    ALTER TABLE user_profiles ALTER COLUMN created_at SET DEFAULT now();
  END IF;
END $$;

-- Add default value for updated_at if it doesn't already have one
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' 
    AND column_name = 'updated_at' 
    AND column_default IS NOT NULL
  ) THEN
    ALTER TABLE user_profiles ALTER COLUMN updated_at SET DEFAULT now();
  END IF;
END $$;