/*
  # Fix user profile creation trigger

  1. Functions
    - Drop and recreate `handle_new_user()` function with proper error handling
    - Use SECURITY DEFINER to bypass RLS during profile creation
    - Extract email and full_name from user metadata

  2. Triggers
    - Ensure trigger is properly configured on auth.users table
    - Trigger executes after INSERT on new user registration

  3. Security
    - Function runs with elevated privileges to create profiles
    - Proper error handling to prevent signup failures
*/

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;

-- Create the function to handle new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_profiles (
    id,
    email,
    full_name,
    phone,
    date_of_birth,
    preferred_platforms,
    total_spent,
    total_won,
    total_bets,
    win_rate,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    NULL,
    NULL,
    '{}',
    0,
    0,
    0,
    0,
    NOW(),
    NOW()
  );
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error but don't prevent user creation
    RAISE LOG 'Error creating user profile for user %: %', NEW.id, SQLERRM;
    RETURN NEW;
END;
$$;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();