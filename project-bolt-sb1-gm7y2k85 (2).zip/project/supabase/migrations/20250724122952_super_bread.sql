/*
  # Configuration simple des profils utilisateur

  1. Tables
    - Suppression et recréation de `user_profiles` avec structure simplifiée
    - Pas de trigger automatique pour éviter les erreurs
  
  2. Sécurité
    - RLS activé avec politiques basiques
    - Politiques pour lecture/écriture des propres données
  
  3. Approche
    - Création manuelle des profils via l'application
    - Pas de dépendance aux triggers Supabase
*/

-- Supprimer la table existante et tout ce qui va avec
DROP TABLE IF EXISTS user_profiles CASCADE;

-- Créer la table user_profiles simplifiée
CREATE TABLE user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL,
  phone text,
  date_of_birth date,
  preferred_platforms text[] DEFAULT '{}',
  total_spent numeric DEFAULT 0,
  total_won numeric DEFAULT 0,
  total_bets integer DEFAULT 0,
  win_rate numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Activer RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Politiques RLS simples
CREATE POLICY "Users can read own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Index pour les performances
CREATE INDEX IF NOT EXISTS user_profiles_email_idx ON user_profiles(email);