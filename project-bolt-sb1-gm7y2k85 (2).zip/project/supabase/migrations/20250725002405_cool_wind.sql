/*
  # Fix user_profiles table constraints

  1. Table Updates
    - Make `phone` and `date_of_birth` nullable with proper defaults
    - Ensure all numeric fields have proper defaults
    - Add proper constraints for data integrity

  2. Security
    - Update RLS policies to allow proper user creation
    - Ensure trigger can create profiles without RLS conflicts

  3. Trigger Function
    - Create robust trigger function for automatic profile creation
    - Handle all edge cases and provide proper error handling
*/

-- First, let's make sure the user_profiles table has the correct structure
ALTER TABLE user_profiles 
  ALTER COLUMN phone DROP NOT NULL,
  ALTER COLUMN date_of_birth DROP NOT NULL,
  ALTER COLUMN total_spent SET DEFAULT 0,
  ALTER COLUMN total_won SET DEFAULT 0,
  ALTER COLUMN total_bets SET DEFAULT 0,
  ALTER COLUMN win_rate SET DEFAULT 0,
  ALTER COLUMN preferred_platforms SET DEFAULT '{}',
  ALTER COLUMN created_at SET DEFAULT now(),
  ALTER COLUMN updated_at SET DEFAULT now();

-- Drop existing trigger and function if they exist
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create a robust function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_profiles (
    id,
    email,
    full_name,
    phone,
    date_of_birth,
    preferred_platforms,
    total_spent,
    total_won,
    total_bets,
    win_rate,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    NULL,
    NULL,
    '{}',
    0,
    0,
    0,
    0,
    NOW(),
    NOW()
  );
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error but don't fail the user creation
    RAISE WARNING 'Could not create user profile for %: %', NEW.id, SQLERRM;
    RETURN NEW;
END;
$$;

-- Create the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Update RLS policies to ensure they work correctly
DROP POLICY IF EXISTS "Users can insert own profile" ON user_profiles;
DROP POLICY IF EXISTS "user_profiles_insert_own" ON user_profiles;

-- Create a comprehensive insert policy
CREATE POLICY "user_profiles_insert_policy" ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Ensure the trigger function can bypass RLS
GRANT USAGE ON SCHEMA public TO postgres;
GRANT ALL ON public.user_profiles TO postgres;